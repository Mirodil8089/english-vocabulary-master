import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Translation proxy endpoint
app.post('/api/translate', async (req: Request, res: Response) => {
  try {
    const { text, sourceLang, targetLang } = req.body;
    if (!text) {
      return res.status(400).json({ error: 'Matn kiritilmagan' });
    }

    const langpair = `${sourceLang || 'en'}|${targetLang || 'uz'}`;
    const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${langpair}`;

    const response = await fetch(url);
    if (!response.ok) {
      return res.status(502).json({ error: 'Tarjima xizmati javob bermadi' });
    }

    const data = await response.json();
    const translatedText = data?.responseData?.translatedText || '';

    return res.json({
      translatedText,
      sourceText: text,
      sourceLang,
      targetLang,
    });
  } catch (err) {
    console.error('Translation error:', err);
    return res.status(500).json({ error: 'Server xatoligi' });
  }
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    try {
      const { createServer } = await import('vite');
      const vite = await createServer({
        server: { middlewareMode: true, host: '0.0.0.0', port: PORT },
        appType: 'spa',
      });
      app.use(vite.middlewares);
    } catch {
      // If vite middleware is not needed, static serving fallback
      app.use(express.static(path.resolve(__dirname, 'dist')));
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`English Vocabulary Master server listening on http://0.0.0.0:${PORT}`);
  });
}

// Only start when invoked directly as server
if (process.env.RUN_EXPRESS === 'true') {
  startServer();
}

export default app;
