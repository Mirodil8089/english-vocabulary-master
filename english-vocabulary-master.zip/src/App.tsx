import React, { useState, useEffect, useCallback } from 'react';
import { Navbar } from './components/Navbar';
import { VocabularySection } from './components/VocabularySection';
import { WithdomSearchSection } from './components/WithdomSearchSection';
import { KnowledgeQuizSection } from './components/KnowledgeQuizSection';
import { AddWordModal } from './components/AddWordModal';
import { EditWordModal } from './components/EditWordModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { ShuffleMemorizeModal } from './components/ShuffleMemorizeModal';
import { StatsAndBackupModal } from './components/StatsAndBackupModal';
import { WordItem, QuizSessionRecord } from './types';
import { storageService } from './services/storage';

export default function App() {
  const [activeTab, setActiveTab] = useState<'vocab' | 'withdom' | 'quiz' | 'stats'>('vocab');
  const [words, setWords] = useState<WordItem[]>([]);
  const [quizHistory, setQuizHistory] = useState<QuizSessionRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [prefilledWord, setPrefilledWord] = useState<{
    english?: string;
    uzbek?: string;
    exampleEn?: string;
    phonetic?: string;
  } | undefined>(undefined);

  const [editingWord, setEditingWord] = useState<WordItem | null>(null);
  const [deletingWord, setDeletingWord] = useState<WordItem | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isShuffleOpen, setIsShuffleOpen] = useState(false);
  const [isStatsModalOpen, setIsStatsModalOpen] = useState(false);

  // Toast notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3200);
  };

  // Load data from IndexedDB
  const loadData = useCallback(async () => {
    try {
      const loadedWords = await storageService.getAllWords();
      setWords(loadedWords);
      const loadedQuiz = await storageService.getQuizHistory();
      setQuizHistory(loadedQuiz);
    } catch (err) {
      console.error('Ma\'lumotlarni yuklashda xatolik:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Handle word addition
  const handleWordAdded = async (
    newWordData: Omit<WordItem, 'id' | 'createdAt' | 'updatedAt' | 'timesReviewed' | 'correctCount' | 'incorrectCount' | 'difficultyScore' | 'status'>
  ) => {
    const created = await storageService.addWord(newWordData);
    setWords((prev) => [created, ...prev]);
    showToast(`"${created.english}" lug'atingizga muvaffaqiyatli qo'shildi!`);
  };

  // Handle bulk words addition
  const handleBulkWordsAdded = async (
    wordsList: Array<Omit<WordItem, 'id' | 'createdAt' | 'updatedAt' | 'timesReviewed' | 'correctCount' | 'incorrectCount' | 'difficultyScore' | 'status'>>
  ) => {
    const createdList: WordItem[] = [];
    for (const item of wordsList) {
      const created = await storageService.addWord(item);
      createdList.push(created);
    }
    setWords((prev) => [...createdList, ...prev]);
    showToast(`${createdList.length} ta yangi so'z muvaffaqiyatli qo'shildi!`);
  };

  // Handle word edit
  const handleWordUpdated = async (updatedWord: WordItem) => {
    const saved = await storageService.updateWord(updatedWord);
    setWords((prev) => prev.map((w) => (w.id === saved.id ? saved : w)));
    showToast(`"${saved.english}" muvaffaqiyatli tahrirlandi!`);
  };

  // Handle word deletion
  const handleConfirmDelete = async () => {
    if (!deletingWord) return;
    setIsDeleting(true);
    try {
      await storageService.deleteWord(deletingWord.id);
      setWords((prev) => prev.filter((w) => w.id !== deletingWord.id));
      showToast(`"${deletingWord.english}" o'chirildi.`);
      setDeletingWord(null);
    } catch (e) {
      console.error('O\'chirishda xatolik:', e);
    } finally {
      setIsDeleting(false);
    }
  };

  // Record a review result (called from Section 1 Shuffle or Section 3 Quiz)
  const handleRecordReview = async (wordId: string, known: boolean) => {
    const updated = await storageService.recordReview(wordId, known);
    if (updated) {
      setWords((prev) => prev.map((w) => (w.id === wordId ? updated : w)));
    }
  };

  // Finish quiz session
  const handleFinishQuizSession = async (stats: {
    total: number;
    correct: number;
    incorrect: number;
  }) => {
    const session = await storageService.saveQuizSession({
      total: stats.total,
      correct: stats.correct,
      incorrect: stats.incorrect,
      mode: activeTab === 'quiz' ? 'know_or_not' : 'shuffle_memorize',
    });
    setQuizHistory((prev) => [session, ...prev]);
  };

  // From Withdom search: 1-click addition to vocabulary
  const handleAddFromSearch = (wordData: {
    english: string;
    uzbek: string;
    exampleEn?: string;
    phonetic?: string;
  }) => {
    // Open add modal prefilled
    setPrefilledWord(wordData);
    setIsAddModalOpen(true);
  };

  // Navigation tab switcher handling
  const handleTabChange = (tab: 'vocab' | 'withdom' | 'quiz' | 'stats') => {
    if (tab === 'stats') {
      setIsStatsModalOpen(true);
    } else {
      setActiveTab(tab);
    }
  };

  const masteredCount = words.filter((w) => w.status === 'mastered').length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-600 selection:text-white">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={handleTabChange}
        wordsCount={words.length}
        masteredCount={masteredCount}
        isAudioEnabled={isAudioEnabled}
        toggleAudio={() => setIsAudioEnabled(!isAudioEnabled)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {isLoading ? (
          <div className="h-96 flex flex-col items-center justify-center space-y-4">
            <div className="w-12 h-12 rounded-full border-4 border-indigo-500/20 border-t-indigo-500 animate-spin" />
            <p className="text-sm text-slate-400">Lug'atlar bazasi yuklanmoqda...</p>
          </div>
        ) : (
          <>
            {/* 1-BO'LIM: MENING LUG'ATLARIM */}
            {activeTab === 'vocab' && (
              <VocabularySection
                words={words}
                onOpenAddModal={() => {
                  setPrefilledWord(undefined);
                  setIsAddModalOpen(true);
                }}
                onOpenEditModal={(word) => setEditingWord(word)}
                onOpenDeleteModal={(word) => setDeletingWord(word)}
                onOpenShuffleMemorize={() => setIsShuffleOpen(true)}
              />
            )}

            {/* 2-BO'LIM: WITHDOM ONLAYN LUG'AT VA KITOBDAN QIDIRISH */}
            {activeTab === 'withdom' && (
              <WithdomSearchSection
                onAddWordFromSearch={handleAddFromSearch}
                existingWords={words}
              />
            )}

            {/* 3-BO'LIM: BILASANMI YOKI YO'QMI? */}
            {activeTab === 'quiz' && (
              <KnowledgeQuizSection
                words={words}
                onRecordReview={handleRecordReview}
                onFinishSession={handleFinishQuizSession}
              />
            )}
          </>
        )}
      </main>

      {/* Toast Notification Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 md:bottom-8 left-1/2 -translate-x-1/2 z-50 bg-slate-900 border border-indigo-500/40 text-white px-5 py-3 rounded-2xl shadow-2xl text-xs font-semibold flex items-center space-x-2 animate-in fade-in slide-in-from-bottom-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Add Word Modal */}
      <AddWordModal
        isOpen={isAddModalOpen}
        onClose={() => {
          setIsAddModalOpen(false);
          setPrefilledWord(undefined);
        }}
        onWordAdded={handleWordAdded}
        onBulkWordsAdded={handleBulkWordsAdded}
        existingWords={words}
        prefilledWord={prefilledWord}
      />

      {/* Edit Word Modal */}
      <EditWordModal
        word={editingWord}
        isOpen={!!editingWord}
        onClose={() => setEditingWord(null)}
        onSave={handleWordUpdated}
      />

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        word={deletingWord}
        isOpen={!!deletingWord}
        onClose={() => setDeletingWord(null)}
        onConfirm={handleConfirmDelete}
        isDeleting={isDeleting}
      />

      {/* Shuffle Memorization Modal (1-Bo'lim C) */}
      <ShuffleMemorizeModal
        words={words}
        isOpen={isShuffleOpen}
        onClose={() => setIsShuffleOpen(false)}
        onRecordReview={handleRecordReview}
        onFinishSession={handleFinishQuizSession}
      />

      {/* Stats and Backup Modal */}
      <StatsAndBackupModal
        isOpen={isStatsModalOpen}
        onClose={() => setIsStatsModalOpen(false)}
        words={words}
        quizHistory={quizHistory}
        onDataImported={loadData}
      />
    </div>
  );
}
