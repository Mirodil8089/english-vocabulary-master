export type WordStatus = 'new' | 'learning' | 'mastered';

export interface WordItem {
  id: string;
  english: string;
  uzbek: string;
  transcription?: string;
  partOfSpeech?: string;
  exampleEn?: string;
  exampleUz?: string;
  category: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
  status: WordStatus;
  // Learning stats
  timesReviewed: number;
  correctCount: number;
  incorrectCount: number;
  lastReviewedAt?: string;
  difficultyScore: number; // 1 (easy) to 5 (difficult)
}

export interface QuizSessionRecord {
  id: string;
  timestamp: string;
  total: number;
  correct: number;
  incorrect: number;
  mode: 'know_or_not' | 'shuffle_memorize';
}

export interface SearchHistoryItem {
  id: string;
  query: string;
  type: 'word' | 'book' | 'phrase';
  timestamp: string;
  resultsCount: number;
}

export interface WithdomBookExcerpt {
  bookTitle: string;
  author: string;
  year?: string;
  passage: string;
  highlightWord: string;
  sourceUrl?: string;
}

export interface WithdomDefinition {
  definition: string;
  uzbekDefinition: string;
  example?: string;
  exampleUz?: string;
  synonyms?: string[];
}

export interface WithdomSearchResult {
  id: string;
  word: string;
  phonetic?: string;
  audioUrl?: string;
  partOfSpeech?: string;
  primaryTranslationUz: string;
  definitions: WithdomDefinition[];
  bookExcerpts: WithdomBookExcerpt[];
  sourceName: string;
  sourceDescription: string;
  legalNotice: string;
}

export interface DailyGoalStats {
  date: string; // YYYY-MM-DD
  wordsReviewed: number;
  wordsMastered: number;
  targetCount: number;
}
