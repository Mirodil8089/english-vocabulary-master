import React from 'react';
import { AlertTriangle, Trash2, X } from 'lucide-react';
import { WordItem } from '../types';

interface DeleteConfirmModalProps {
  word: WordItem | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => Promise<void>;
  isDeleting: boolean;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  word,
  isOpen,
  onClose,
  onConfirm,
  isDeleting,
}) => {
  if (!isOpen || !word) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">So'zni o'chirishni tasdiqlang</h3>
            <p className="text-xs text-slate-400">Bu amal qaytarilmaydi</p>
          </div>
        </div>

        <p className="text-sm text-slate-300 mb-4 bg-slate-800/60 p-3 rounded-xl border border-slate-700/60">
          Rostdan ham <span className="font-bold text-rose-400">"{word.english}"</span> ({word.uzbek}) so'zini lug'atingizdan o'chirib tashlamoqchimisiz?
        </p>

        <div className="flex items-center justify-end space-x-3">
          <button
            type="button"
            onClick={onClose}
            disabled={isDeleting}
            className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition"
          >
            Bekor qilish
          </button>
          <button
            type="button"
            onClick={onConfirm}
            disabled={isDeleting}
            className="px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 rounded-xl shadow-md transition flex items-center space-x-1.5"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{isDeleting ? 'O\'chirilmoqda...' : 'Ha, o\'chirilsin'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
