import React from 'react';
import { BookOpen, Search, HelpCircle, BarChart3, Sparkles, Volume2, VolumeX } from 'lucide-react';

interface NavbarProps {
  activeTab: 'vocab' | 'withdom' | 'quiz' | 'stats';
  setActiveTab: (tab: 'vocab' | 'withdom' | 'quiz' | 'stats') => void;
  wordsCount: number;
  masteredCount: number;
  isAudioEnabled: boolean;
  toggleAudio: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  wordsCount,
  masteredCount,
  isAudioEnabled,
  toggleAudio,
}) => {
  return (
    <>
      {/* Top Header for Desktop & Tablet */}
      <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('vocab')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-sky-400 flex items-center justify-center shadow-lg shadow-indigo-500/20 text-white">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-lg text-white tracking-tight">Vocabulary Master</span>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  <Sparkles className="w-3 h-3 mr-1 text-indigo-400" /> PRO
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">Inglizcha-O'zbekcha Lug'at & Withdom Qidiruv</p>
            </div>
          </div>

          {/* Center Navigation for Desktop */}
          <nav className="hidden md:flex items-center space-x-1 bg-slate-800/80 p-1 rounded-xl border border-slate-700/60">
            <button
              onClick={() => setActiveTab('vocab')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'vocab'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>Mening Lug'atlarim</span>
              <span className="ml-1.5 px-1.5 py-0.5 text-xs rounded-full bg-slate-900/60 text-slate-300">
                {wordsCount}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('withdom')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'withdom'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <Search className="w-4 h-4 text-emerald-400" />
              <span>Withdom Qidiruv</span>
            </button>

            <button
              onClick={() => setActiveTab('quiz')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'quiz'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <HelpCircle className="w-4 h-4 text-amber-400" />
              <span>Bilasanmi yoki Yo'qmi?</span>
            </button>

            <button
              onClick={() => setActiveTab('stats')}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === 'stats'
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
              }`}
            >
              <BarChart3 className="w-4 h-4 text-sky-400" />
              <span>Statistika</span>
            </button>
          </nav>

          {/* Right actions: Audio Toggle & Quick stats */}
          <div className="flex items-center space-x-3">
            <button
              onClick={toggleAudio}
              title={isAudioEnabled ? "Ovoz yoqilgan" : "Ovoz o'chirilgan"}
              className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition border border-slate-700/70"
            >
              {isAudioEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
            </button>

            <div className="hidden sm:flex items-center bg-slate-800/80 border border-slate-700 px-3 py-1.5 rounded-lg text-xs">
              <span className="text-slate-400 mr-2">O'zlashtirildi:</span>
              <span className="font-bold text-emerald-400">{masteredCount}</span>
              <span className="text-slate-500 mx-1">/</span>
              <span className="text-slate-300">{wordsCount}</span>
            </div>
          </div>
        </div>
      </header>

      {/* Bottom Navigation for Mobile Devices */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-slate-900/95 backdrop-blur-lg border-t border-slate-800 px-2 py-2 flex items-center justify-around shadow-2xl">
        <button
          onClick={() => setActiveTab('vocab')}
          className={`flex flex-col items-center justify-center flex-1 py-1.5 rounded-lg text-xs transition ${
            activeTab === 'vocab' ? 'text-indigo-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <BookOpen className="w-5 h-5 mb-1" />
          <span>Lug'atlarim</span>
        </button>

        <button
          onClick={() => setActiveTab('withdom')}
          className={`flex flex-col items-center justify-center flex-1 py-1.5 rounded-lg text-xs transition ${
            activeTab === 'withdom' ? 'text-indigo-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Search className="w-5 h-5 mb-1 text-emerald-400" />
          <span>Withdom</span>
        </button>

        <button
          onClick={() => setActiveTab('quiz')}
          className={`flex flex-col items-center justify-center flex-1 py-1.5 rounded-lg text-xs transition ${
            activeTab === 'quiz' ? 'text-indigo-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <HelpCircle className="w-5 h-5 mb-1 text-amber-400" />
          <span>Bilasanmi?</span>
        </button>

        <button
          onClick={() => setActiveTab('stats')}
          className={`flex flex-col items-center justify-center flex-1 py-1.5 rounded-lg text-xs transition ${
            activeTab === 'stats' ? 'text-indigo-400 font-semibold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <BarChart3 className="w-5 h-5 mb-1 text-sky-400" />
          <span>Statistika</span>
        </button>
      </div>
    </>
  );
};
