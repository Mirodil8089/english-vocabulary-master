import React, { useState, useEffect } from 'react';
import { X, Shuffle, Eye, Check, AlertCircle, ArrowRight, Volume2, Pause, Play, Sparkles, RefreshCw } from 'lucide-react';
import confetti from 'canvas-confetti';
import { WordItem } from '../types';
import { audioService } from '../services/audioService';

interface ShuffleMemorizeModalProps {
  words: WordItem[];
  isOpen: boolean;
  onClose: () => void;
  onRecordReview: (wordId: string, known: boolean) => Promise<void>;
  onFinishSession?: (stats: { total: number; correct: number; incorrect: number }) => void;
}

export const ShuffleMemorizeModal: React.FC<ShuffleMemorizeModalProps> = ({
  words,
  isOpen,
  onClose,
  onRecordReview,
  onFinishSession,
}) => {
  // Session queue
  const [deck, setDeck] = useState<WordItem[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnswerRevealed, setIsAnswerRevealed] = useState(false);
  const [direction, setDirection] = useState<'en_to_uz' | 'uz_to_en'>('en_to_uz');

  // Session stats
  const [knownCount, setKnownCount] = useState(0);
  const [unknownCount, setUnknownCount] = useState(0);
  const [answeredState, setAnsweredState] = useState<'none' | 'known' | 'unknown'>('none');
  const [isPaused, setIsPaused] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);

  // Initialize or shuffle deck when modal opens
  useEffect(() => {
    if (isOpen && words.length > 0) {
      startNewSession();
    }
  }, [isOpen, words]);

  const startNewSession = () => {
    // Weighted shuffle: Prioritize higher difficulty scores and words reviewed less often
    const shuffled = [...words].sort(() => Math.random() - 0.5);
    // Sort slightly to put difficulty 4-5 first
    shuffled.sort((a, b) => b.difficultyScore - a.difficultyScore + (Math.random() * 2 - 1));

    setDeck(shuffled);
    setCurrentIndex(0);
    setIsAnswerRevealed(false);
    setAnsweredState('none');
    setKnownCount(0);
    setUnknownCount(0);
    setIsPaused(false);
    setIsCompleted(false);
  };

  if (!isOpen) return null;

  if (deck.length === 0) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
        <div className="bg-slate-900 border border-slate-700 rounded-2xl p-6 max-w-sm text-center">
          <AlertCircle className="w-10 h-10 text-amber-400 mx-auto mb-3" />
          <h3 className="text-base font-bold text-white mb-2">Lug'at bo'sh</h3>
          <p className="text-xs text-slate-300 mb-4">Yodlashni boshlash uchun avval kamida 1 ta so'z qo'shing.</p>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-indigo-600 text-white text-xs font-semibold rounded-xl"
          >
            Yopish
          </button>
        </div>
      </div>
    );
  }

  const currentWord = deck[currentIndex];

  const handleRevealAnswer = () => {
    setIsAnswerRevealed(true);
    if (currentWord) {
      audioService.speak(currentWord.english);
    }
  };

  const handleAnswer = async (known: boolean) => {
    if (!currentWord) return;

    setIsAnswerRevealed(true);
    setAnsweredState(known ? 'known' : 'unknown');

    // Record review in database
    await onRecordReview(currentWord.id, known);

    if (known) {
      setKnownCount((prev) => prev + 1);
    } else {
      setUnknownCount((prev) => prev + 1);
      // Re-queue the unknown word to practice again later in the session
      setDeck((prevDeck) => {
        const updated = [...prevDeck];
        // Insert 3 steps ahead or at the end
        const insertPos = Math.min(updated.length, currentIndex + 3);
        updated.splice(insertPos, 0, currentWord);
        return updated;
      });
    }
  };

  const handleNextQuestion = () => {
    if (currentIndex + 1 < deck.length) {
      setCurrentIndex((prev) => prev + 1);
      setIsAnswerRevealed(false);
      setAnsweredState('none');
    } else {
      // Completed session!
      setIsCompleted(true);
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
      if (onFinishSession) {
        onFinishSession({
          total: knownCount + unknownCount,
          correct: knownCount,
          incorrect: unknownCount,
        });
      }
    }
  };

  const progressPercent = Math.min(100, Math.round(((currentIndex) / deck.length) * 100));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden my-6 flex flex-col max-h-[92vh]">
        {/* Top Header */}
        <div className="px-6 py-4 bg-slate-800/80 border-b border-slate-700/70 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/30 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
              <Shuffle className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Aralashtirib Yodlash</h2>
              <p className="text-xs text-slate-400">Savol {currentIndex + 1} / {deck.length}</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setIsPaused(!isPaused)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white bg-slate-800 border border-slate-700 transition"
              title={isPaused ? "Davom ettirish" : "To'xtatib turish"}
            >
              {isPaused ? <Play className="w-4 h-4 text-emerald-400" /> : <Pause className="w-4 h-4" />}
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700/60 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-800 h-1.5">
          <div
            className="bg-gradient-to-r from-indigo-500 to-sky-400 h-1.5 transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Paused state overlay */}
        {isPaused ? (
          <div className="p-8 text-center my-auto">
            <div className="w-12 h-12 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center mx-auto mb-3 text-slate-300">
              <Pause className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">Test to'xtatildi</h3>
            <p className="text-xs text-slate-400 mb-6 max-w-xs mx-auto">
              Istalgan vaqt davom ettirishingiz yoki mashg'ulotni yakunlashingiz mumkin.
            </p>
            <div className="flex items-center justify-center space-x-3">
              <button
                onClick={() => setIsPaused(false)}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-indigo-600/30 flex items-center space-x-2"
              >
                <Play className="w-4 h-4" />
                <span>Davom ettirish</span>
              </button>
              <button
                onClick={onClose}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold border border-slate-700"
              >
                Chiqish
              </button>
            </div>
          </div>
        ) : isCompleted ? (
          /* Completion Screen */
          <div className="p-8 text-center my-auto">
            <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center mx-auto mb-4 text-emerald-400">
              <Sparkles className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-white mb-1">Ajoyib natija!</h3>
            <p className="text-xs text-slate-400 mb-6">Mashg'ulot muvaffaqiyatli yakunlandi</p>

            {/* Score cards */}
            <div className="grid grid-cols-2 gap-3 mb-6 max-w-xs mx-auto">
              <div className="bg-emerald-950/30 border border-emerald-500/30 p-3 rounded-xl">
                <span className="text-xs text-emerald-400 font-medium block">Bilganlaringiz:</span>
                <span className="text-2xl font-black text-emerald-400">{knownCount}</span>
              </div>
              <div className="bg-rose-950/30 border border-rose-500/30 p-3 rounded-xl">
                <span className="text-xs text-rose-400 font-medium block">Qaytariladiganlar:</span>
                <span className="text-2xl font-black text-rose-400">{unknownCount}</span>
              </div>
            </div>

            <div className="flex items-center justify-center space-x-3">
              <button
                onClick={startNewSession}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-indigo-600/30 flex items-center space-x-2"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Qaytadan boshlash</span>
              </button>
              <button
                onClick={onClose}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold border border-slate-700"
              >
                Tugatish
              </button>
            </div>
          </div>
        ) : (
          /* Active Question Card */
          <div className="p-6 flex-1 flex flex-col justify-between overflow-y-auto">
            {/* Top stats and direction switch */}
            <div className="flex items-center justify-between text-xs text-slate-400 mb-4 bg-slate-800/40 px-3 py-2 rounded-xl border border-slate-700/60">
              <div className="flex items-center space-x-3">
                <span className="flex items-center text-emerald-400">
                  <Check className="w-3.5 h-3.5 mr-1" /> {knownCount} ta bilindi
                </span>
                <span className="flex items-center text-rose-400">
                  <AlertCircle className="w-3.5 h-3.5 mr-1" /> {unknownCount} ta takror
                </span>
              </div>

              {/* Direction switch */}
              <button
                onClick={() => setDirection(direction === 'en_to_uz' ? 'uz_to_en' : 'en_to_uz')}
                className="text-xs font-medium text-indigo-400 hover:text-indigo-300 bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-700 flex items-center"
              >
                <span>{direction === 'en_to_uz' ? 'EN ➔ UZ' : 'UZ ➔ EN'}</span>
              </button>
            </div>

            {/* Central Card */}
            <div className="my-auto py-4">
              <div className="text-center bg-slate-800/50 border border-slate-700/80 rounded-2xl p-6 sm:p-8 shadow-inner">
                <span className="inline-block px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 mb-3">
                  {currentWord?.category || 'Umumiy'}
                </span>

                {/* Primary Prompt Word */}
                <div className="flex items-center justify-center space-x-2 mb-2">
                  <h3 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
                    {direction === 'en_to_uz' ? currentWord?.english : currentWord?.uzbek}
                  </h3>
                  {direction === 'en_to_uz' && (
                    <button
                      onClick={() => currentWord && audioService.speak(currentWord.english)}
                      className="p-1.5 rounded-lg bg-slate-700/60 text-indigo-400 hover:text-indigo-300 hover:bg-slate-700 transition"
                      title="Ovozni eshitish"
                    >
                      <Volume2 className="w-5 h-5" />
                    </button>
                  )}
                </div>

                {direction === 'en_to_uz' && currentWord?.transcription && (
                  <p className="text-sm font-mono text-slate-400 mb-4">{currentWord.transcription}</p>
                )}

                {/* Answer Box */}
                {isAnswerRevealed ? (
                  <div className="mt-6 pt-5 border-t border-slate-700/80 animate-in fade-in zoom-in-95 duration-200">
                    <span className="text-xs font-semibold text-slate-400 block mb-1">To'g'ri tarjima:</span>
                    <p className="text-2xl font-bold text-emerald-400">
                      {direction === 'en_to_uz' ? currentWord?.uzbek : currentWord?.english}
                    </p>

                    {currentWord?.exampleEn && (
                      <div className="mt-4 p-3 bg-slate-900/60 rounded-xl border border-slate-800 text-left text-xs space-y-1">
                        <p className="text-slate-300 italic">"{currentWord.exampleEn}"</p>
                        {currentWord.exampleUz && (
                          <p className="text-slate-400">"{currentWord.exampleUz}"</p>
                        )}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="mt-6 pt-4 border-t border-slate-700/50">
                    <p className="text-xs text-slate-500 italic">
                      Tarjima yashirilgan. Eslab ko'ring va "Javobni ko'rsatish" tugmasini bosing.
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="space-y-3 pt-4 border-t border-slate-800">
              {!isAnswerRevealed ? (
                <button
                  onClick={handleRevealAnswer}
                  className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-semibold shadow-lg shadow-indigo-600/30 flex items-center justify-center space-x-2 transition"
                >
                  <Eye className="w-4 h-4" />
                  <span>Javobni ko'rsatish</span>
                </button>
              ) : answeredState === 'none' ? (
                /* Choice Buttons: Bilaman vs Bilmayman */
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => handleAnswer(false)}
                    className="py-3 px-4 bg-rose-600/20 hover:bg-rose-600/30 border border-rose-500/50 text-rose-300 rounded-xl text-sm font-bold flex items-center justify-center space-x-2 transition"
                  >
                    <AlertCircle className="w-4 h-4 text-rose-400" />
                    <span>Bilmayman ✗</span>
                  </button>
                  <button
                    onClick={() => handleAnswer(true)}
                    className="py-3 px-4 bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/50 text-emerald-300 rounded-xl text-sm font-bold flex items-center justify-center space-x-2 transition"
                  >
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>Bilaman ✓</span>
                  </button>
                </div>
              ) : (
                /* Next Question Button */
                <button
                  onClick={handleNextQuestion}
                  className="w-full py-3 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-sm font-semibold shadow-lg shadow-sky-600/30 flex items-center justify-center space-x-2 transition"
                >
                  <span>Keyingi savol</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
