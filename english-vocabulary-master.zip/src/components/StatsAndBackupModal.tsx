import React, { useState } from 'react';
import {
  X, Download, Upload, BarChart3, Database, User, ShieldCheck, Check,
  AlertCircle, RefreshCw, FileText, FileSpreadsheet, HardDrive, Award
} from 'lucide-react';
import { WordItem, QuizSessionRecord } from '../types';
import { storageService } from '../services/storage';

interface StatsAndBackupModalProps {
  isOpen: boolean;
  onClose: () => void;
  words: WordItem[];
  quizHistory: QuizSessionRecord[];
  onDataImported: () => Promise<void>;
}

export const StatsAndBackupModal: React.FC<StatsAndBackupModalProps> = ({
  isOpen,
  onClose,
  words,
  quizHistory,
  onDataImported,
}) => {
  const [activeTab, setActiveTab] = useState<'stats' | 'backup' | 'profile'>('stats');
  const [username, setUsername] = useState(storageService.getUserId());
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [isResetting, setIsResetting] = useState(false);

  if (!isOpen) return null;

  // Statistics calculations
  const totalWords = words.length;
  const masteredWords = words.filter((w) => w.status === 'mastered').length;
  const learningWords = words.filter((w) => w.status === 'learning').length;
  const newWords = words.filter((w) => w.status === 'new').length;
  const masteredPercentage = totalWords > 0 ? Math.round((masteredWords / totalWords) * 100) : 0;

  const totalReviews = words.reduce((acc, w) => acc + w.timesReviewed, 0);
  const totalCorrect = words.reduce((acc, w) => acc + w.correctCount, 0);
  const accuracyRate = totalReviews > 0 ? Math.round((totalCorrect / totalReviews) * 100) : 0;

  // Handle JSON export
  const handleExportJSON = async () => {
    setIsExporting(true);
    try {
      const json = await storageService.exportJSON();
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `english_vocab_backup_${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Exportda xato:', e);
    } finally {
      setIsExporting(false);
    }
  };

  // Handle CSV export
  const handleExportCSV = async () => {
    setIsExporting(true);
    try {
      const csv = await storageService.exportCSV();
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `english_vocab_${new Date().toISOString().slice(0, 10)}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('CSV Exportda xato:', e);
    } finally {
      setIsExporting(false);
    }
  };

  // Handle File Import
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    setImportStatus(null);

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        if (file.name.endsWith('.json')) {
          const res = await storageService.importJSON(text);
          setImportStatus(`Muvaffaqiyatli: ${res.importedCount} ta yangi so'z qo'shildi (${res.duplicateCount} ta takroriy o'tkazib yuborildi).`);
        } else if (file.name.endsWith('.csv')) {
          const res = await storageService.importCSV(text);
          setImportStatus(`Muvaffaqiyatli: ${res.importedCount} ta yangi so'z qo'shildi (${res.duplicateCount} ta takroriy o'tkazib yuborildi).`);
        } else {
          setImportStatus('Faqat .json yoki .csv fayllar qabul qilinadi.');
        }
        await onDataImported();
      } catch (err) {
        setImportStatus('Faylni import qilishda xatolik: ' + (err instanceof Error ? err.message : ''));
      } finally {
        setIsImporting(false);
      }
    };
    reader.readAsText(file);
  };

  const handleUpdateProfile = () => {
    storageService.setUserId(username);
    setImportStatus('Foydalanuvchi profili yangilandi!');
  };

  const handleResetToDefault = async () => {
    if (window.confirm("Barcha ma'lumotlarni boshlang'ich namunaviy so'zlarga qaytarmoqchimisiz?")) {
      setIsResetting(true);
      await storageService.resetAllToSeed();
      await onDataImported();
      setIsResetting(false);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden my-6">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-800/80 border-b border-slate-700/70 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-sky-600/30 border border-sky-500/40 flex items-center justify-center text-sky-400">
              <BarChart3 className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Statistika & Ma'lumotlarni Saqlash</h2>
              <p className="text-xs text-slate-400">O'zlashtirish ko'rsatkichlari, IndexedDB va Zaxira</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700/60 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="px-6 pt-4">
          <div className="grid grid-cols-3 gap-2 bg-slate-800/60 p-1 rounded-xl border border-slate-700/60">
            <button
              onClick={() => setActiveTab('stats')}
              className={`py-2 text-xs font-semibold rounded-lg transition flex items-center justify-center space-x-1.5 ${
                activeTab === 'stats'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Statistika</span>
            </button>
            <button
              onClick={() => setActiveTab('backup')}
              className={`py-2 text-xs font-semibold rounded-lg transition flex items-center justify-center space-x-1.5 ${
                activeTab === 'backup'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              <span>Eksport & Import</span>
            </button>
            <button
              onClick={() => setActiveTab('profile')}
              className={`py-2 text-xs font-semibold rounded-lg transition flex items-center justify-center space-x-1.5 ${
                activeTab === 'profile'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>Profil & Sozlamalar</span>
            </button>
          </div>
        </div>

        {/* Tab 1: Stats */}
        {activeTab === 'stats' && (
          <div className="p-6 space-y-5">
            {/* Main Progress KPI */}
            <div className="bg-gradient-to-r from-indigo-950/60 to-slate-800/80 p-5 rounded-2xl border border-indigo-500/20">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-300">
                  Umumiy o'zlashtirish darajasi
                </span>
                <span className="text-lg font-black text-indigo-400">{masteredPercentage}%</span>
              </div>
              <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden mb-3">
                <div
                  className="bg-gradient-to-r from-indigo-500 to-emerald-400 h-2.5 transition-all duration-500"
                  style={{ width: `${masteredPercentage}%` }}
                />
              </div>
              <p className="text-xs text-slate-400">
                Jami <strong className="text-white">{totalWords}</strong> ta so'zdan <strong className="text-emerald-400">{masteredWords}</strong> tasi to'liq yodlangan.
              </p>
            </div>

            {/* Grid metrics */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-slate-800/50 p-3.5 rounded-xl border border-slate-700/60">
                <span className="text-[11px] text-slate-400 block mb-1">Jami so'zlar:</span>
                <span className="text-xl font-black text-white">{totalWords}</span>
              </div>
              <div className="bg-slate-800/50 p-3.5 rounded-xl border border-slate-700/60">
                <span className="text-[11px] text-slate-400 block mb-1">Yangi so'zlar:</span>
                <span className="text-xl font-black text-indigo-400">{newWords}</span>
              </div>
              <div className="bg-slate-800/50 p-3.5 rounded-xl border border-slate-700/60">
                <span className="text-[11px] text-slate-400 block mb-1">O'rganilmoqda:</span>
                <span className="text-xl font-black text-amber-400">{learningWords}</span>
              </div>
              <div className="bg-slate-800/50 p-3.5 rounded-xl border border-slate-700/60">
                <span className="text-[11px] text-slate-400 block mb-1">Aniqlik darajasi:</span>
                <span className="text-xl font-black text-emerald-400">{accuracyRate}%</span>
              </div>
            </div>

            {/* Quiz Sessions History */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Oxirgi mashg'ulotlar tarixi:
              </h4>
              {quizHistory.length === 0 ? (
                <p className="text-xs text-slate-500 bg-slate-800/30 p-3 rounded-xl border border-slate-800">
                  Hali mashg'ulotlar o'tkazilmagan. "Bilasanmi yoki yo'qmi?" yoki "Yodlash" bo'limida test topshiring.
                </p>
              ) : (
                <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                  {quizHistory.slice(0, 5).map((q) => (
                    <div
                      key={q.id}
                      className="flex items-center justify-between bg-slate-800/40 px-3.5 py-2 rounded-xl border border-slate-700/50 text-xs"
                    >
                      <div className="flex items-center space-x-2">
                        <Award className="w-3.5 h-3.5 text-amber-400" />
                        <span className="text-slate-300 font-medium">
                          {q.mode === 'know_or_not' ? 'Bilasanmi yoki yo\'qmi' : 'Aralashtirib yodlash'}
                        </span>
                      </div>
                      <div className="flex items-center space-x-3 text-slate-400">
                        <span className="text-emerald-400 font-semibold">{q.correct} to'g'ri</span>
                        <span className="text-rose-400 font-semibold">{q.incorrect} xato</span>
                        <span className="text-slate-500 text-[11px]">
                          {new Date(q.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 2: Backup (Export / Import) */}
        {activeTab === 'backup' && (
          <div className="p-6 space-y-5">
            {/* Offline & Persistence info */}
            <div className="bg-slate-800/40 p-4 rounded-2xl border border-slate-700/70 flex items-start space-x-3 text-xs text-slate-300">
              <HardDrive className="w-5 h-5 text-indigo-400 flex-shrink-0 mt-0.5" />
              <div>
                <strong className="text-white block mb-0.5">Xavfsiz IndexedDB & Offline Saqlash</strong>
                <p className="text-slate-400">
                  Barcha lug'atlaringiz brauzeringizning IndexedDB xotirasida saqlanadi. Ilova internet bo'lmaganda ham to'liq ishlaydi va sahifa yopilganda hech qanday so'z yo'qolmaydi.
                </p>
              </div>
            </div>

            {/* Export options */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Lug'atni zaxiraga saqlash (Eksport):
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  onClick={handleExportJSON}
                  disabled={isExporting}
                  className="p-3.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-left transition flex items-center justify-between"
                >
                  <div className="flex items-center space-x-2.5">
                    <FileText className="w-4 h-4 text-indigo-400" />
                    <div>
                      <span className="text-xs font-bold text-white block">JSON Formatida</span>
                      <span className="text-[11px] text-slate-400">Barcha ma'lumotlar va statistika</span>
                    </div>
                  </div>
                  <Download className="w-4 h-4 text-slate-400" />
                </button>

                <button
                  onClick={handleExportCSV}
                  disabled={isExporting}
                  className="p-3.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl text-left transition flex items-center justify-between"
                >
                  <div className="flex items-center space-x-2.5">
                    <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                    <div>
                      <span className="text-xs font-bold text-white block">CSV / Excel Formatida</span>
                      <span className="text-[11px] text-slate-400">Jadval shaklida o'qish uchun</span>
                    </div>
                  </div>
                  <Download className="w-4 h-4 text-slate-400" />
                </button>
              </div>
            </div>

            {/* Import options */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Lug'atni yuklab olish (Import):
              </label>
              <label className="flex flex-col items-center justify-center p-6 bg-slate-800/40 hover:bg-slate-800/70 border-2 border-dashed border-slate-700 rounded-2xl cursor-pointer transition">
                <Upload className="w-6 h-6 text-indigo-400 mb-2" />
                <span className="text-xs font-semibold text-white">
                  JSON yoki CSV faylni tanlang
                </span>
                <span className="text-[11px] text-slate-500 mt-0.5">
                  Fayldagi so'zlar avtomatik tekshirilib, takrorlanmaganlari qo'shiladi
                </span>
                <input
                  type="file"
                  accept=".json,.csv"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>

            {importStatus && (
              <div className="p-3 bg-emerald-500/15 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center space-x-2">
                <Check className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>{importStatus}</span>
              </div>
            )}
          </div>
        )}

        {/* Tab 3: Profile & Settings */}
        {activeTab === 'profile' && (
          <div className="p-6 space-y-5">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Foydalanuvchi profili (Lug'atlarni ajratish):
              </label>
              <div className="flex items-center space-x-2">
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Ismingiz yoki profil nomi"
                  className="flex-1 px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white text-sm focus:ring-2 focus:ring-indigo-500"
                />
                <button
                  onClick={handleUpdateProfile}
                  className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition"
                >
                  Saqlash
                </button>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                Turli foydalanuvchilar o'z lug'atlarini alohida profil ostida boshqarishi mumkin.
              </p>
            </div>

            <div className="pt-4 border-t border-slate-800">
              <label className="block text-xs font-bold uppercase tracking-wider text-rose-400 mb-2">
                Xavfli zona:
              </label>
              <button
                onClick={handleResetToDefault}
                disabled={isResetting}
                className="px-4 py-2 bg-rose-600/20 hover:bg-rose-600/30 border border-rose-500/40 text-rose-300 rounded-xl text-xs font-semibold transition flex items-center space-x-2"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Boshlang'ich namunaviy lug'at holatiga qaytarish</span>
              </button>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-800/80 border-t border-slate-700/70 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl border border-slate-700"
          >
            Yopish
          </button>
        </div>
      </div>
    </div>
  );
};
