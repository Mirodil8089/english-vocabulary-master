import React, { useState, useEffect } from 'react';
import {
  Search, BookOpen, ExternalLink, Plus, Check, Volume2, History, Trash2,
  Sparkles, AlertCircle, Bookmark, ShieldCheck, ChevronRight, FileText, Info
} from 'lucide-react';
import { WithdomSearchResult, SearchHistoryItem, WordItem } from '../types';
import { withdomService } from '../services/withdomService';
import { storageService } from '../services/storage';
import { audioService } from '../services/audioService';

interface WithdomSearchSectionProps {
  onAddWordFromSearch: (wordData: {
    english: string;
    uzbek: string;
    exampleEn?: string;
    phonetic?: string;
  }) => void;
  existingWords: WordItem[];
}

export const WithdomSearchSection: React.FC<WithdomSearchSectionProps> = ({
  onAddWordFromSearch,
  existingWords,
}) => {
  const [query, setQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [results, setResults] = useState<WithdomSearchResult[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [searchHistory, setSearchHistory] = useState<SearchHistoryItem[]>([]);
  const [addedWordMap, setAddedWordMap] = useState<Record<string, boolean>>({});
  const [activeTab, setActiveTab] = useState<'all' | 'dictionary' | 'books'>('all');
  const [selectedExcerpt, setSelectedExcerpt] = useState<{
    bookTitle: string;
    author: string;
    passage: string;
    year?: string;
    sourceUrl?: string;
  } | null>(null);

  useEffect(() => {
    loadSearchHistory();
  }, []);

  const loadSearchHistory = async () => {
    const history = await storageService.getSearchHistory();
    setSearchHistory(history);
  };

  const handleSearch = async (searchKeyword?: string) => {
    const q = (searchKeyword !== undefined ? searchKeyword : query).trim();
    if (!q) return;

    setQuery(q);
    setIsSearching(true);
    setHasSearched(true);

    try {
      const searchResults = await withdomService.search(q);
      setResults(searchResults);
      await storageService.addSearchHistory(q, 'word', searchResults.length);
      await loadSearchHistory();
    } catch (err) {
      console.error('Qidiruvda xato:', err);
      setResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  const handleClearHistory = async () => {
    await storageService.clearSearchHistory();
    setSearchHistory([]);
  };

  const handleAddWord = (result: WithdomSearchResult) => {
    const example = result.definitions.find((d) => d.example)?.example || '';
    onAddWordFromSearch({
      english: result.word,
      uzbek: result.primaryTranslationUz,
      exampleEn: example,
      phonetic: result.phonetic,
    });

    setAddedWordMap((prev) => ({ ...prev, [result.word.toLowerCase()]: true }));
  };

  const isWordAlreadyAdded = (word: string) => {
    const norm = word.toLowerCase().trim();
    return (
      addedWordMap[norm] ||
      existingWords.some((w) => w.english.toLowerCase().trim() === norm)
    );
  };

  return (
    <div className="space-y-6 pb-24 md:pb-12">
      {/* Top Banner & Withdom Source Explanation */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-emerald-950/40 to-slate-900 border border-emerald-900/40 p-6 sm:p-8 shadow-xl">
        <div className="flex items-center space-x-2 text-emerald-400 text-xs font-bold uppercase tracking-wider mb-2">
          <BookOpen className="w-4 h-4" />
          <span>2-Bo'lim: Withdom Onlayn Lug'at va Kitobdan Qidirish</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Withdom & Ochiq Adabiyotlar Qidiruvi
        </h1>
        <p className="text-sm text-slate-300 mt-2 max-w-2xl leading-relaxed">
          So'z, ibora, kitob nomi yoki adabiy kontekstni qidiring. Ilova ochiq leksik lug'at bazasi (FreeDictionary), Project Gutenberg va Open Library ochiq klassik kitoblar korpusi orqali natijalarni to'g'ridan-to'g'ri ilova ichida taqdim etadi.
        </p>

        {/* Source and Transparency Notice */}
        <div className="mt-4 p-3 bg-slate-900/80 rounded-2xl border border-emerald-500/20 flex items-start space-x-3 text-xs text-slate-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-slate-200">Qonuniylik va manba shaffofligi:</span>
            <p className="mt-0.5">
              Withdom mustaqil manba bo'lib, uning aniq yopiq API litsenziyasi bo'lmagani uchun tizim mualliflik huquqlariga to'liq rioya qiladi: jamoat mulki (Public Domain) bo'lgan ochiq klassik asarlar va qonuniy leksik kataloglardan ruxsat etilgan ta'limiy parchalar keltiriladi.
            </p>
          </div>
        </div>
      </div>

      {/* Search Input Box */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-lg space-y-4">
        <div className="relative">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            placeholder="So'z, ibora yoki kitob mavzusini kiriting (masalan: wisdom, school, knowledge, reading...)"
            className="w-full pl-11 pr-32 py-3.5 bg-slate-800 border border-slate-700 rounded-2xl text-white placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-inner"
          />
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <button
            onClick={() => handleSearch()}
            disabled={isSearching || !query.trim()}
            className="absolute right-2 top-2 bottom-2 px-5 bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-700 text-white rounded-xl text-xs font-bold transition flex items-center space-x-1.5 shadow-md"
          >
            {isSearching ? (
              <span className="animate-spin text-sm">⏳</span>
            ) : (
              <Search className="w-4 h-4" />
            )}
            <span>Qidirish</span>
          </button>
        </div>

        {/* Quick Suggestion Chips */}
        <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
          <span className="text-slate-500">Tavsiya etilgan:</span>
          {['wisdom', 'knowledge', 'diligent', 'opportunity', 'book', 'freedom', 'achieve'].map((w) => (
            <button
              key={w}
              onClick={() => handleSearch(w)}
              className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 border border-slate-700/60 transition"
            >
              {w}
            </button>
          ))}
        </div>

        {/* Search History Section */}
        {searchHistory.length > 0 && (
          <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center space-x-2 overflow-x-auto py-1">
              <History className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
              <span className="text-xs text-slate-400 flex-shrink-0">Tarix:</span>
              {searchHistory.slice(0, 6).map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleSearch(item.query)}
                  className="px-2 py-0.5 rounded text-xs bg-slate-800/80 hover:bg-slate-700 text-slate-300 whitespace-nowrap transition"
                >
                  {item.query}
                </button>
              ))}
            </div>

            <button
              onClick={handleClearHistory}
              className="text-xs text-slate-500 hover:text-rose-400 flex items-center space-x-1 transition"
              title="Qidiruv tarixini tozalash"
            >
              <Trash2 className="w-3 h-3" />
              <span>Tarixni tozalash</span>
            </button>
          </div>
        )}
      </div>

      {/* Results Filter Tabs */}
      {results.length > 0 && (
        <div className="flex items-center space-x-2 bg-slate-900/60 p-1 rounded-xl border border-slate-800 w-fit">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === 'all'
                ? 'bg-emerald-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Barchasi
          </button>
          <button
            onClick={() => setActiveTab('dictionary')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === 'dictionary'
                ? 'bg-emerald-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Lug'at ma'nolari
          </button>
          <button
            onClick={() => setActiveTab('books')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeTab === 'books'
                ? 'bg-emerald-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Kitob parchalaridan
          </button>
        </div>
      )}

      {/* Results Content */}
      {isSearching ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-12 text-center">
          <div className="w-12 h-12 rounded-full border-4 border-emerald-500/20 border-t-emerald-500 animate-spin mx-auto mb-4" />
          <h3 className="text-base font-bold text-white mb-1">Withdom va ochiq manbalardan qidirilmoqda...</h3>
          <p className="text-xs text-slate-400">Leksik lug'at va ochiq kitoblar arxivi tekshirilmoqda</p>
        </div>
      ) : hasSearched && results.length === 0 ? (
        /* Empty State */
        <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-12 text-center">
          <AlertCircle className="w-12 h-12 text-amber-500/80 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-white mb-1">Hech qanday natija topilmadi</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto mb-4">
            "{query}" so'zi yoki parchasi bo'yicha ma'lumot topilmadi. So'z to'g'ri yozilganini tekshiring yoki umumiyroq so'z bilan sinab ko'ring.
          </p>
          <p className="text-[11px] text-slate-500 italic">
            Ilova mualliflik huquqiga rioya qilgani holda soxta natija ishlab chiqarmaydi.
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {results.map((res) => {
            const isAdded = isWordAlreadyAdded(res.word);

            return (
              <div
                key={res.id}
                className="bg-slate-900/80 border border-slate-800 hover:border-slate-700 rounded-3xl p-6 sm:p-8 shadow-xl transition space-y-6"
              >
                {/* Result Header */}
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-6 border-b border-slate-800">
                  <div>
                    <div className="flex items-center space-x-3 mb-1">
                      <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                        {res.word}
                      </h2>
                      <button
                        onClick={() => audioService.speak(res.word)}
                        className="p-1.5 rounded-xl bg-slate-800 text-emerald-400 hover:bg-slate-700 transition"
                        title="Talaffuzni tinglash"
                      >
                        <Volume2 className="w-5 h-5" />
                      </button>
                    </div>

                    <div className="flex items-center space-x-3 text-xs text-slate-400 font-mono">
                      {res.phonetic && <span>{res.phonetic}</span>}
                      {res.partOfSpeech && (
                        <span className="bg-slate-800 px-2 py-0.5 rounded text-[11px] font-sans italic text-slate-300">
                          {res.partOfSpeech}
                        </span>
                      )}
                    </div>

                    {/* Primary Translation */}
                    <div className="mt-3 flex items-center space-x-2">
                      <span className="text-xs text-slate-400">O'zbekcha tarjima:</span>
                      <span className="text-lg font-bold text-emerald-400">
                        {res.primaryTranslationUz}
                      </span>
                    </div>
                  </div>

                  {/* 1-Click "Mening lug'atlarimga qo'shish" Button (Required by brief) */}
                  <div>
                    <button
                      onClick={() => handleAddWord(res)}
                      disabled={isAdded}
                      className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center space-x-2 shadow-lg ${
                        isAdded
                          ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30 cursor-default'
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30'
                      }`}
                    >
                      {isAdded ? (
                        <>
                          <Check className="w-4 h-4 text-emerald-400" />
                          <span>Lug'atingizda mavjud</span>
                        </>
                      ) : (
                        <>
                          <Plus className="w-4 h-4" />
                          <span>Mening lug'atlarimga qo'shish</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Definitions (Dictionary tab) */}
                {(activeTab === 'all' || activeTab === 'dictionary') && res.definitions.length > 0 && (
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center">
                      <FileText className="w-3.5 h-3.5 mr-1 text-emerald-400" /> Lug'aviy ma'no va izohlar
                    </h4>
                    <div className="space-y-3">
                      {res.definitions.map((def, idx) => (
                        <div
                          key={idx}
                          className="bg-slate-800/40 p-4 rounded-2xl border border-slate-700/50 space-y-1.5"
                        >
                          <p className="text-sm text-slate-200">
                            <strong className="text-emerald-400 mr-2">{idx + 1}.</strong>
                            {def.definition}
                          </p>
                          {def.example && (
                            <p className="text-xs text-slate-400 italic pl-5">
                              Misol: "{def.example}"
                            </p>
                          )}
                          {def.synonyms && def.synonyms.length > 0 && (
                            <div className="text-[11px] text-slate-500 pl-5 pt-1">
                              Sinonimlar: {def.synonyms.join(', ')}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Book Excerpts (Books tab) */}
                {(activeTab === 'all' || activeTab === 'books') && res.bookExcerpts.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center">
                        <Bookmark className="w-3.5 h-3.5 mr-1 text-sky-400" /> Klassik kitoblar va adabiyotlardan parchalar
                      </h4>
                      <span className="text-[11px] text-slate-500">
                        Qonuniy ochiq preview
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {res.bookExcerpts.map((excerpt, eIdx) => (
                        <div
                          key={eIdx}
                          className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 hover:border-slate-700 transition flex flex-col justify-between"
                        >
                          <div>
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-bold text-xs text-sky-300">
                                {excerpt.bookTitle}
                              </span>
                              {excerpt.year && (
                                <span className="text-[11px] text-slate-500">{excerpt.year}</span>
                              )}
                            </div>
                            <p className="text-[11px] text-slate-400 mb-2">
                              Muallif: <strong className="text-slate-300">{excerpt.author}</strong>
                            </p>
                            <p className="text-xs text-slate-300 italic leading-relaxed bg-slate-900/80 p-3 rounded-xl border border-slate-800/80">
                              "{excerpt.passage}"
                            </p>
                          </div>

                          <div className="mt-3 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px]">
                            <button
                              onClick={() => setSelectedExcerpt(excerpt)}
                              className="text-indigo-400 hover:text-indigo-300 flex items-center font-medium"
                            >
                              <span>Ilova ichida to'liq o'qish</span>
                              <ChevronRight className="w-3.5 h-3.5 ml-0.5" />
                            </button>

                            {excerpt.sourceUrl && (
                              <a
                                href={excerpt.sourceUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="text-slate-500 hover:text-slate-300 flex items-center space-x-1"
                              >
                                <span>Manba</span>
                                <ExternalLink className="w-3 h-3" />
                              </a>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Source attribution footer */}
                <div className="pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500">
                  <div className="flex items-center space-x-1.5">
                    <Info className="w-3.5 h-3.5 text-slate-400" />
                    <span>{res.sourceName} • {res.legalNotice}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* In-app Excerpt Reader Modal (Prevents forced external redirects) */}
      {selectedExcerpt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-white">{selectedExcerpt.bookTitle}</h3>
                <p className="text-xs text-slate-400">
                  {selectedExcerpt.author} {selectedExcerpt.year ? `(${selectedExcerpt.year})` : ''}
                </p>
              </div>
              <button
                onClick={() => setSelectedExcerpt(null)}
                className="text-slate-400 hover:text-white p-1"
              >
                ✕
              </button>
            </div>

            <div className="bg-slate-950/80 p-5 rounded-2xl border border-slate-800 text-sm text-slate-200 leading-relaxed italic">
              "{selectedExcerpt.passage}"
            </div>

            <div className="text-xs text-slate-400">
              Ushbu parcha ta'limiy maqsadlarda jamoat mulki (Project Gutenberg / Open Library) litsenziyasi ostida taqdim etilgan.
            </div>

            <div className="flex items-center justify-end space-x-3 pt-2">
              {selectedExcerpt.sourceUrl && (
                <a
                  href={selectedExcerpt.sourceUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold border border-slate-700 flex items-center space-x-1.5"
                >
                  <span>Kutubxona sahifasi</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
              <button
                onClick={() => setSelectedExcerpt(null)}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold"
              >
                Tushunarli
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
