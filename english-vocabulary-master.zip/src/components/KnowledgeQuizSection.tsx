import React, { useState, useEffect, useMemo } from 'react';
import {
  HelpCircle, Check, X, RotateCcw, Shuffle, Filter, Volume2, ArrowRight,
  Sparkles, Flame, Trophy, Award, Settings, CheckCircle2, AlertOctagon
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { WordItem } from '../types';
import { audioService } from '../services/audioService';

interface KnowledgeQuizSectionProps {
  words: WordItem[];
  onRecordReview: (wordId: string, known: boolean) => Promise<void>;
  onFinishSession?: (stats: { total: number; correct: number; incorrect: number }) => void;
}

export const KnowledgeQuizSection: React.FC<KnowledgeQuizSectionProps> = ({
  words,
  onRecordReview,
  onFinishSession,
}) => {
  // Options
  const [onlyUnknown, setOnlyUnknown] = useState(false);
  const [direction, setDirection] = useState<'en_to_uz' | 'uz_to_en'>('en_to_uz');
  const [autoAdvance, setAutoAdvance] = useState(true);

  // Deck & Card state
  const [deck, setDeck] = useState<WordItem[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [cardRevealed, setCardRevealed] = useState(false);
  const [lastAnswer, setLastAnswer] = useState<'known' | 'unknown' | null>(null);

  // Session counters
  const [sessionCorrect, setSessionCorrect] = useState(0);
  const [sessionIncorrect, setSessionIncorrect] = useState(0);
  const [sessionFinished, setSessionFinished] = useState(false);

  // Initialize deck based on filter & options
  const initializeDeck = () => {
    let pool = [...words];
    if (onlyUnknown) {
      pool = pool.filter((w) => w.status !== 'mastered' || w.difficultyScore >= 3 || w.incorrectCount > 0);
    }
    // Shuffle pool
    const shuffled = [...pool].sort(() => Math.random() - 0.5);

    setDeck(shuffled);
    setCurrentIndex(0);
    setCardRevealed(false);
    setLastAnswer(null);
    setSessionCorrect(0);
    setSessionIncorrect(0);
    setSessionFinished(false);
  };

  useEffect(() => {
    if (words.length > 0) {
      initializeDeck();
    }
  }, [words, onlyUnknown]);

  const currentWord = deck[currentIndex];

  const handleUserAnswer = async (known: boolean) => {
    if (!currentWord || cardRevealed) return;

    setCardRevealed(true);
    setLastAnswer(known ? 'known' : 'unknown');

    // Play pronunciation if enabled
    audioService.speak(currentWord.english);

    // Save to persistent database
    await onRecordReview(currentWord.id, known);

    if (known) {
      setSessionCorrect((prev) => prev + 1);
    } else {
      setSessionIncorrect((prev) => prev + 1);
      // Re-insert this word later in the deck for spaced repetition
      setDeck((prevDeck) => {
        const copy = [...prevDeck];
        const nextPos = Math.min(copy.length, currentIndex + 4);
        copy.splice(nextPos, 0, currentWord);
        return copy;
      });
    }

    // Auto-advance after small pause if enabled
    if (autoAdvance) {
      setTimeout(() => {
        moveToNextWord();
      }, 1200);
    }
  };

  const moveToNextWord = () => {
    if (currentIndex + 1 < deck.length) {
      setCurrentIndex((prev) => prev + 1);
      setCardRevealed(false);
      setLastAnswer(null);
    } else {
      // Completed!
      setSessionFinished(true);
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 },
      });
      if (onFinishSession) {
        onFinishSession({
          total: sessionCorrect + sessionIncorrect,
          correct: sessionCorrect,
          incorrect: sessionIncorrect,
        });
      }
    }
  };

  const totalWordsCount = words.length;
  const masteredCount = words.filter((w) => w.status === 'mastered').length;
  const masteredPercent = totalWordsCount > 0 ? Math.round((masteredCount / totalWordsCount) * 100) : 0;
  const progressRatio = deck.length > 0 ? Math.round(((currentIndex) / deck.length) * 100) : 0;

  if (words.length === 0) {
    return (
      <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-12 text-center max-w-lg mx-auto">
        <HelpCircle className="w-12 h-12 text-slate-600 mx-auto mb-3" />
        <h3 className="text-lg font-bold text-white mb-2">Lug'atda so'z yo'q</h3>
        <p className="text-xs text-slate-400 mb-6">
          "Bilasanmi yoki yo'qmi?" testini boshlash uchun avval 1-bo'limda yoki Withdom orqali so'zlar qo'shing.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-24 md:pb-12 max-w-4xl mx-auto">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-amber-950/40 via-slate-900 to-slate-900 border border-amber-900/40 p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
              <HelpCircle className="w-4 h-4" />
              <span>3-Bo'lim: Bilasanmi yoki Yo'qmi?</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Tezkor So'z Mashg'uloti
            </h1>
            <p className="text-sm text-slate-300 mt-1">
              Lug'atingizdagi so'zlarni ikkita katta tugma orqali o'zlashtiring: Bilaman yoki Bilmayman.
            </p>
          </div>

          {/* Overall Stats Pills */}
          <div className="flex sm:flex-col items-end gap-2 text-xs">
            <div className="bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700/60 flex items-center space-x-2">
              <Trophy className="w-4 h-4 text-amber-400" />
              <span className="text-slate-300">
                O'zlashtirilgan: <strong className="text-white">{masteredCount} ({masteredPercent}%)</strong>
              </span>
            </div>
            <div className="bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700/60 flex items-center space-x-2">
              <Flame className="w-4 h-4 text-orange-400" />
              <span className="text-slate-300">
                Ushbu seansda: <strong className="text-emerald-400">+{sessionCorrect}</strong>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Control Bar: Filters, Direction, and Shuffle */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div className="flex flex-wrap items-center gap-2">
          {/* Shuffle button */}
          <button
            onClick={initializeDeck}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-semibold border border-slate-700/80 flex items-center space-x-1.5 transition"
            title="Savollarni aralashtirish"
          >
            <Shuffle className="w-3.5 h-3.5 text-indigo-400" />
            <span>Aralashtirish</span>
          </button>

          {/* Only unknown filter */}
          <button
            onClick={() => setOnlyUnknown(!onlyUnknown)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition flex items-center space-x-1.5 ${
              onlyUnknown
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 shadow-sm'
                : 'bg-slate-800 text-slate-400 border-slate-700/80 hover:text-white'
            }`}
          >
            <AlertOctagon className="w-3.5 h-3.5 text-rose-400" />
            <span>Faqat bilmagan so'zlar</span>
          </button>

          {/* Direction toggle: EN->UZ / UZ->EN */}
          <button
            onClick={() => setDirection(direction === 'en_to_uz' ? 'uz_to_en' : 'en_to_uz')}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-semibold border border-slate-700/80 flex items-center space-x-1.5 transition"
          >
            <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
            <span>{direction === 'en_to_uz' ? 'Inglizcha ➔ O\'zbekcha' : 'O\'zbekcha ➔ Inglizcha'}</span>
          </button>
        </div>

        {/* Auto advance toggle */}
        <label className="flex items-center space-x-2 text-xs text-slate-400 cursor-pointer select-none">
          <input
            type="checkbox"
            checked={autoAdvance}
            onChange={(e) => setAutoAdvance(e.target.checked)}
            className="rounded border-slate-700 text-indigo-600 focus:ring-0"
          />
          <span>Avtomatik keyingisiga o'tish</span>
        </label>
      </div>

      {sessionFinished ? (
        /* Finished Celebration Card */
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 sm:p-12 text-center shadow-2xl space-y-6">
          <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-emerald-500/30 to-teal-500/20 border border-emerald-500/40 flex items-center justify-center mx-auto text-emerald-400 shadow-xl">
            <Award className="w-10 h-10" />
          </div>

          <div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">Tabriklaymiz!</h2>
            <p className="text-sm text-slate-400 mt-1">Ushbu guruhdagi barcha savollarni ko'rib chiqdingiz.</p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 max-w-md mx-auto">
            <div className="bg-slate-800/60 p-4 rounded-2xl border border-slate-700/70">
              <span className="text-xs text-slate-400 block mb-1">Ko'rib chiqildi</span>
              <strong className="text-2xl text-white font-extrabold">{sessionCorrect + sessionIncorrect} ta</strong>
            </div>
            <div className="bg-emerald-950/40 p-4 rounded-2xl border border-emerald-500/30">
              <span className="text-xs text-emerald-400 block mb-1">Bilindi</span>
              <strong className="text-2xl text-emerald-400 font-extrabold">{sessionCorrect} ta</strong>
            </div>
            <div className="bg-rose-950/40 p-4 rounded-2xl border border-rose-500/30 col-span-2 sm:col-span-1">
              <span className="text-xs text-rose-400 block mb-1">Qaytariladi</span>
              <strong className="text-2xl text-rose-400 font-extrabold">{sessionIncorrect} ta</strong>
            </div>
          </div>

          <div className="flex items-center justify-center space-x-4 pt-4">
            <button
              onClick={initializeDeck}
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl text-sm font-bold shadow-lg shadow-indigo-600/30 flex items-center space-x-2 transition"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Yana mashq qilish</span>
            </button>
          </div>
        </div>
      ) : (
        /* Active Flashcard Drill Area */
        <div className="space-y-6">
          {/* Progress Header */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Savol: <strong className="text-white">{currentIndex + 1}</strong> / {deck.length}</span>
              <span>Jami aniqlik: <strong className="text-emerald-400">{sessionCorrect} to'g'ri</strong> / <strong className="text-rose-400">{sessionIncorrect} xato</strong></span>
            </div>
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-amber-500 via-indigo-500 to-emerald-400 h-2 transition-all duration-300"
                style={{ width: `${progressRatio}%` }}
              />
            </div>
          </div>

          {/* Main Flashcard Card */}
          <div className="relative min-h-[320px] sm:min-h-[360px] bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-slate-800 rounded-3xl p-8 sm:p-12 shadow-2xl flex flex-col items-center justify-between text-center overflow-hidden">
            {/* Top Tag */}
            <div className="flex items-center space-x-2">
              <span className="px-3 py-1 rounded-full text-xs font-semibold bg-slate-800 border border-slate-700 text-slate-300">
                {currentWord?.category || 'Umumiy'}
              </span>
              {currentWord?.status === 'mastered' && (
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  O'zlashtirilgan
                </span>
              )}
            </div>

            {/* Word Display */}
            <div className="my-auto py-6">
              <div className="flex items-center justify-center space-x-3 mb-2">
                <h2 className="text-4xl sm:text-5xl font-black text-white tracking-tight">
                  {direction === 'en_to_uz' ? currentWord?.english : currentWord?.uzbek}
                </h2>
                <button
                  onClick={() => currentWord && audioService.speak(currentWord.english)}
                  className="p-2 rounded-full bg-slate-800 text-indigo-400 hover:text-white hover:bg-slate-700 transition"
                  title="Talaffuzni tinglash"
                >
                  <Volume2 className="w-6 h-6" />
                </button>
              </div>

              {direction === 'en_to_uz' && currentWord?.transcription && (
                <p className="text-base font-mono text-slate-400 mb-2">
                  {currentWord.transcription}
                </p>
              )}

              {/* Translation revealed state */}
              {cardRevealed ? (
                <div className="mt-6 pt-6 border-t border-slate-800 animate-in fade-in zoom-in-95 duration-200">
                  <span className="text-xs uppercase font-bold tracking-wider text-slate-400 block mb-1">
                    To'g'ri ma'nosi:
                  </span>
                  <p className="text-2xl sm:text-3xl font-extrabold text-emerald-400">
                    {direction === 'en_to_uz' ? currentWord?.uzbek : currentWord?.english}
                  </p>

                  {currentWord?.exampleEn && (
                    <div className="mt-4 p-3 bg-slate-800/40 rounded-xl border border-slate-800 max-w-md mx-auto text-xs text-slate-300 italic">
                      "{currentWord.exampleEn}"
                    </div>
                  )}
                </div>
              ) : (
                <div className="mt-6">
                  <p className="text-xs text-slate-500">
                    Tarjimani o'zingizda tekshirib, quyidagi tugmalardan birini tanlang
                  </p>
                </div>
              )}
            </div>

            {/* Answer state badge if selected */}
            {lastAnswer && (
              <div className="absolute top-4 right-4">
                {lastAnswer === 'known' ? (
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center space-x-1">
                    <Check className="w-3.5 h-3.5" />
                    <span>Bilindi!</span>
                  </span>
                ) : (
                  <span className="px-3 py-1 rounded-full text-xs font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center space-x-1">
                    <X className="w-3.5 h-3.5" />
                    <span>Keyinroq takrorlanadi</span>
                  </span>
                )}
              </div>
            )}
          </div>

          {/* TWO BIG PROMINENT ACTION BUTTONS: BILAMAN vs BILMAYMAN (Strictly required by brief) */}
          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => handleUserAnswer(false)}
              disabled={cardRevealed}
              className="py-5 px-6 rounded-2xl bg-gradient-to-b from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 disabled:opacity-50 text-white font-extrabold text-base sm:text-lg shadow-xl shadow-rose-900/40 active:scale-95 transition-all flex items-center justify-center space-x-2"
            >
              <X className="w-6 h-6 stroke-[3]" />
              <span>BILMAYMAN ✗</span>
            </button>

            <button
              onClick={() => handleUserAnswer(true)}
              disabled={cardRevealed}
              className="py-5 px-6 rounded-2xl bg-gradient-to-b from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 disabled:opacity-50 text-white font-extrabold text-base sm:text-lg shadow-xl shadow-emerald-900/40 active:scale-95 transition-all flex items-center justify-center space-x-2"
            >
              <Check className="w-6 h-6 stroke-[3]" />
              <span>BILAMAN ✓</span>
            </button>
          </div>

          {/* Next Button when card is revealed */}
          {cardRevealed && (
            <div className="pt-2 animate-in fade-in">
              <button
                onClick={moveToNextWord}
                className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-bold text-sm shadow-lg shadow-indigo-600/30 flex items-center justify-center space-x-2 transition"
              >
                <span>Keyingi so'zga o'tish</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
