import React, { useState, useEffect } from 'react';
import { X, Search, Sparkles, Check, AlertCircle, Volume2, Plus, ListPlus, Loader2 } from 'lucide-react';
import { WordItem } from '../types';
import { translationService } from '../services/translationService';
import { audioService } from '../services/audioService';
import { VOCABULARY_CATEGORIES } from '../data/initialVocabulary';

interface AddWordModalProps {
  isOpen: boolean;
  onClose: () => void;
  onWordAdded: (word: Omit<WordItem, 'id' | 'createdAt' | 'updatedAt' | 'timesReviewed' | 'correctCount' | 'incorrectCount' | 'difficultyScore' | 'status'>) => Promise<void>;
  onBulkWordsAdded: (words: Array<Omit<WordItem, 'id' | 'createdAt' | 'updatedAt' | 'timesReviewed' | 'correctCount' | 'incorrectCount' | 'difficultyScore' | 'status'>>) => Promise<void>;
  existingWords: WordItem[];
  prefilledWord?: { english?: string; uzbek?: string; exampleEn?: string; phonetic?: string };
}

export const AddWordModal: React.FC<AddWordModalProps> = ({
  isOpen,
  onClose,
  onWordAdded,
  onBulkWordsAdded,
  existingWords,
  prefilledWord,
}) => {
  const [modalMode, setModalMode] = useState<'single' | 'bulk'>('single');
  // Two choices for single input:
  // 'en_first' = "Inglizcha so'z kiritaman" (school -> maktab)
  // 'uz_first' = "O'zbekcha so'z kiritaman" (maktab -> school)
  const [inputDirection, setInputDirection] = useState<'en_first' | 'uz_first'>('en_first');

  // Single word state
  const [primaryInput, setPrimaryInput] = useState('');
  const [englishWord, setEnglishWord] = useState('');
  const [uzbekWord, setUzbekWord] = useState('');
  const [transcription, setTranscription] = useState('');
  const [partOfSpeech, setPartOfSpeech] = useState('noun');
  const [exampleEn, setExampleEn] = useState('');
  const [exampleUz, setExampleUz] = useState('');
  const [category, setCategory] = useState('Kundalik hayot');
  const [isLoadingTranslation, setIsLoadingTranslation] = useState(false);
  const [translationSource, setTranslationSource] = useState<string>('');
  const [duplicateWarning, setDuplicateWarning] = useState<string | null>(null);

  // Bulk state
  const [bulkText, setBulkText] = useState('');
  const [bulkParsedCount, setBulkParsedCount] = useState(0);
  const [bulkDuplicateCount, setBulkDuplicateCount] = useState(0);

  // Error/Success state
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (prefilledWord) {
      if (prefilledWord.english) {
        setInputDirection('en_first');
        setPrimaryInput(prefilledWord.english);
        setEnglishWord(prefilledWord.english);
      }
      if (prefilledWord.uzbek) {
        setUzbekWord(prefilledWord.uzbek);
      }
      if (prefilledWord.phonetic) {
        setTranscription(prefilledWord.phonetic);
      }
      if (prefilledWord.exampleEn) {
        setExampleEn(prefilledWord.exampleEn);
      }
    }
  }, [prefilledWord]);

  if (!isOpen) return null;

  // Handle auto-translation lookup when typing or pressing button
  const handleFetchTranslation = async (queryText?: string) => {
    const textToSearch = (queryText !== undefined ? queryText : primaryInput).trim();
    if (!textToSearch) return;

    setIsLoadingTranslation(true);
    setErrorMessage(null);

    try {
      const direction = inputDirection === 'en_first' ? 'en_to_uz' : 'uz_to_en';
      const result = await translationService.translate(textToSearch, direction);

      if (inputDirection === 'en_first') {
        setEnglishWord(textToSearch);
        if (result.translatedText) {
          setUzbekWord(result.translatedText);
        }
        if (result.phonetic) setTranscription(result.phonetic);
        if (result.partOfSpeech) setPartOfSpeech(result.partOfSpeech);
        if (result.exampleEn && !exampleEn) setExampleEn(result.exampleEn);
        if (result.exampleUz && !exampleUz) setExampleUz(result.exampleUz);
      } else {
        setUzbekWord(textToSearch);
        if (result.translatedText) {
          setEnglishWord(result.translatedText);
        }
        if (result.phonetic) setTranscription(result.phonetic);
        if (result.partOfSpeech) setPartOfSpeech(result.partOfSpeech);
        if (result.exampleEn && !exampleEn) setExampleEn(result.exampleEn);
        if (result.exampleUz && !exampleUz) setExampleUz(result.exampleUz);
      }

      setTranslationSource(
        result.sourceProvider === 'dictionary_db'
          ? 'Ishonchli lug\'at bazasidan'
          : result.sourceProvider === 'mymemory_api'
          ? 'Onlayn tarjima xizmatidan'
          : 'Qo\'lda kiritish rejimi'
      );

      // Check duplicates
      const checkEn = inputDirection === 'en_first' ? textToSearch : (result.translatedText || englishWord);
      checkDuplicate(checkEn);
    } catch (e) {
      console.warn('Tarjima olishda xatolik:', e);
      setErrorMessage('Tarjima avtomatik topilmadi, iltimos tarjimani qo\'lda kiriting.');
    } finally {
      setIsLoadingTranslation(false);
    }
  };

  const checkDuplicate = (enWord: string) => {
    if (!enWord) {
      setDuplicateWarning(null);
      return;
    }
    const found = existingWords.find((w) => w.english.toLowerCase().trim() === enWord.toLowerCase().trim());
    if (found) {
      setDuplicateWarning(`"${enWord}" so'zi allaqachon lug'atingizda bor (Tarjimasi: ${found.uzbek})`);
    } else {
      setDuplicateWarning(null);
    }
  };

  const handlePrimaryInputChange = (val: string) => {
    setPrimaryInput(val);
    if (inputDirection === 'en_first') {
      setEnglishWord(val);
      checkDuplicate(val);
    } else {
      setUzbekWord(val);
    }
  };

  const handleSaveSingle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!englishWord.trim() || !uzbekWord.trim()) {
      setErrorMessage('Iltimos, ham inglizcha so\'zni, ham o\'zbekcha tarjimani to\'ldiring.');
      return;
    }

    setIsSaving(true);
    setErrorMessage(null);

    try {
      await onWordAdded({
        english: englishWord.trim(),
        uzbek: uzbekWord.trim(),
        transcription: transcription.trim(),
        partOfSpeech: partOfSpeech.trim() || 'noun',
        category,
        exampleEn: exampleEn.trim(),
        exampleUz: exampleUz.trim(),
        tags: [category],
      });

      // Reset and close
      resetForm();
      onClose();
    } catch (err) {
      setErrorMessage('Saqlashda xatolik yuz berdi: ' + (err instanceof Error ? err.message : ''));
    } finally {
      setIsSaving(false);
    }
  };

  // Bulk parser
  const handleBulkTextChange = (text: string) => {
    setBulkText(text);
    const lines = text.split('\n').filter((l) => l.trim().length > 0);
    let parsed = 0;
    let dupes = 0;

    lines.forEach((line) => {
      const parts = line.split(/[-–—:]+/);
      if (parts.length >= 2) {
        const en = parts[0].trim().toLowerCase();
        parsed++;
        if (existingWords.some((w) => w.english.toLowerCase().trim() === en)) {
          dupes++;
        }
      }
    });

    setBulkParsedCount(parsed);
    setBulkDuplicateCount(dupes);
  };

  const handleSaveBulk = async () => {
    const lines = bulkText.split('\n').filter((l) => l.trim().length > 0);
    const toAdd: Array<Omit<WordItem, 'id' | 'createdAt' | 'updatedAt' | 'timesReviewed' | 'correctCount' | 'incorrectCount' | 'difficultyScore' | 'status'>> = [];

    lines.forEach((line) => {
      const parts = line.split(/[-–—:]+/);
      if (parts.length >= 2) {
        const en = parts[0].trim();
        const uz = parts.slice(1).join(' - ').trim();
        if (en && uz) {
          toAdd.push({
            english: en,
            uzbek: uz,
            transcription: '',
            partOfSpeech: 'noun',
            category,
            exampleEn: '',
            exampleUz: '',
            tags: [category],
          });
        }
      }
    });

    if (toAdd.length === 0) {
      setErrorMessage('Hech qanday to\'g\'ri formatdagi so\'z topilmadi. Masalan: school - maktab');
      return;
    }

    setIsSaving(true);
    try {
      await onBulkWordsAdded(toAdd);
      resetForm();
      onClose();
    } catch (e) {
      setErrorMessage('Ommaviy saqlashda xato yuz berdi: ' + (e instanceof Error ? e.message : ''));
    } finally {
      setIsSaving(false);
    }
  };

  const resetForm = () => {
    setPrimaryInput('');
    setEnglishWord('');
    setUzbekWord('');
    setTranscription('');
    setExampleEn('');
    setExampleUz('');
    setDuplicateWarning(null);
    setErrorMessage(null);
    setBulkText('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-800/80 border-b border-slate-700/80 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-600/30 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
              <Plus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Yangi Lug'at Qo'shish</h2>
              <p className="text-xs text-slate-400">So'z va tarjimasini kiriting yoki ommaviy yuklang</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700/60 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector: Yakka so'z vs Ommaviy */}
        <div className="px-6 pt-4">
          <div className="grid grid-cols-2 gap-2 bg-slate-800/60 p-1 rounded-xl border border-slate-700/60">
            <button
              type="button"
              onClick={() => setModalMode('single')}
              className={`py-2 text-xs font-semibold rounded-lg transition flex items-center justify-center space-x-1.5 ${
                modalMode === 'single'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/30'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Yakka so'z qo'shish</span>
            </button>
            <button
              type="button"
              onClick={() => setModalMode('bulk')}
              className={`py-2 text-xs font-semibold rounded-lg transition flex items-center justify-center space-x-1.5 ${
                modalMode === 'bulk'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-700/30'
              }`}
            >
              <ListPlus className="w-3.5 h-3.5" />
              <span>Bir nechta so'z (Ommaviy)</span>
            </button>
          </div>
        </div>

        {modalMode === 'single' ? (
          <form onSubmit={handleSaveSingle} className="p-6 space-y-4">
            {/* Input Direction Choice: Required by brief */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                Kiritish tartibi:
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setInputDirection('en_first');
                    setPrimaryInput(englishWord);
                  }}
                  className={`p-3 rounded-xl border text-left transition flex flex-col justify-between ${
                    inputDirection === 'en_first'
                      ? 'bg-indigo-950/40 border-indigo-500 text-white shadow-md'
                      : 'bg-slate-800/40 border-slate-700/70 text-slate-300 hover:border-slate-600'
                  }`}
                >
                  <span className="text-xs font-bold text-indigo-400">1-Tanlov</span>
                  <span className="text-sm font-semibold mt-1">Inglizcha so'z kiritaman</span>
                  <span className="text-xs text-slate-400 mt-0.5">school → maktab</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setInputDirection('uz_first');
                    setPrimaryInput(uzbekWord);
                  }}
                  className={`p-3 rounded-xl border text-left transition flex flex-col justify-between ${
                    inputDirection === 'uz_first'
                      ? 'bg-indigo-950/40 border-indigo-500 text-white shadow-md'
                      : 'bg-slate-800/40 border-slate-700/70 text-slate-300 hover:border-slate-600'
                  }`}
                >
                  <span className="text-xs font-bold text-emerald-400">2-Tanlov</span>
                  <span className="text-sm font-semibold mt-1">O'zbekcha so'z kiritaman</span>
                  <span className="text-xs text-slate-400 mt-0.5">maktab → school</span>
                </button>
              </div>
            </div>

            {/* Quick search input */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                {inputDirection === 'en_first' ? 'Inglizcha so\'zni kiriting:' : 'O\'zbekcha so\'zni kiriting:'}
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={primaryInput}
                  onChange={(e) => handlePrimaryInputChange(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleFetchTranslation();
                    }
                  }}
                  placeholder={inputDirection === 'en_first' ? 'Masalan: school, book, knowledge...' : 'Masalan: maktab, kitob, bilim...'}
                  className="w-full pl-3.5 pr-28 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
                  autoFocus
                />
                <button
                  type="button"
                  onClick={() => handleFetchTranslation()}
                  disabled={isLoadingTranslation || !primaryInput.trim()}
                  className="absolute right-1.5 top-1.5 bottom-1.5 px-3 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 text-white rounded-lg text-xs font-semibold transition flex items-center space-x-1"
                >
                  {isLoadingTranslation ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Search className="w-3.5 h-3.5" />
                  )}
                  <span>Tarjima top</span>
                </button>
              </div>
            </div>

            {/* Duplicate Warning */}
            {duplicateWarning && (
              <div className="p-3 bg-amber-500/15 border border-amber-500/30 rounded-xl flex items-start space-x-2.5 text-xs text-amber-300">
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-amber-400" />
                <span>{duplicateWarning}</span>
              </div>
            )}

            {/* Editable Confirmation Box: Users can verify and edit both words */}
            <div className="bg-slate-800/40 p-4 rounded-xl border border-slate-700/70 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300 flex items-center">
                  <Check className="w-3.5 h-3.5 mr-1 text-emerald-400" /> Tekshirish va tasdiqlash
                </span>
                {translationSource && (
                  <span className="text-[11px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                    {translationSource}
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* English word */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs text-slate-400">Inglizcha so'z:</label>
                    {englishWord && (
                      <button
                        type="button"
                        onClick={() => audioService.speak(englishWord)}
                        className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center"
                        title="Talaffuzni tinglash"
                      >
                        <Volume2 className="w-3.5 h-3.5 mr-0.5" /> Eshitish
                      </button>
                    )}
                  </div>
                  <input
                    type="text"
                    value={englishWord}
                    onChange={(e) => {
                      setEnglishWord(e.target.value);
                      checkDuplicate(e.target.value);
                    }}
                    placeholder="English word"
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm focus:ring-1 focus:ring-indigo-500"
                    required
                  />
                </div>

                {/* Uzbek translation */}
                <div>
                  <label className="block text-xs text-slate-400 mb-1">O'zbekcha tarjimasi:</label>
                  <input
                    type="text"
                    value={uzbekWord}
                    onChange={(e) => setUzbekWord(e.target.value)}
                    placeholder="O'zbekcha ma'nosi"
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white text-sm focus:ring-1 focus:ring-indigo-500"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Transcription */}
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Transkripsiya (ixtiyoriy):</label>
                  <input
                    type="text"
                    value={transcription}
                    onChange={(e) => setTranscription(e.target.value)}
                    placeholder="/ˈeksəmpl/"
                    className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs"
                  />
                </div>

                {/* Part of Speech */}
                <div>
                  <label className="block text-xs text-slate-400 mb-1">So'z turkumi:</label>
                  <select
                    value={partOfSpeech}
                    onChange={(e) => setPartOfSpeech(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs"
                  >
                    <option value="noun">Noun (Ot)</option>
                    <option value="verb">Verb (Fe'l)</option>
                    <option value="adjective">Adjective (Sifat)</option>
                    <option value="adverb">Adverb (Ravish)</option>
                    <option value="phrase">Phrase (Ibora)</option>
                  </select>
                </div>

                {/* Category */}
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Guruh / Kategoriya:</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs"
                  >
                    {VOCABULARY_CATEGORIES.filter((c) => c !== 'Barchasi').map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Optional Example sentence */}
              <div className="space-y-2 pt-1 border-t border-slate-700/50">
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Misol gap (Inglizcha, ixtiyoriy):</label>
                  <input
                    type="text"
                    value={exampleEn}
                    onChange={(e) => setExampleEn(e.target.value)}
                    placeholder="She walks to school every day."
                    className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">Misol gap tarjimasi (O'zbekcha):</label>
                  <input
                    type="text"
                    value={exampleUz}
                    onChange={(e) => setExampleUz(e.target.value)}
                    placeholder="U har kuni maktabga boradi."
                    className="w-full px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white text-xs"
                  />
                </div>
              </div>
            </div>

            {errorMessage && (
              <div className="p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl text-xs text-rose-300">
                {errorMessage}
              </div>
            )}

            {/* Buttons */}
            <div className="flex items-center justify-end space-x-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition"
              >
                Bekor qilish
              </button>
              <button
                type="submit"
                disabled={isSaving || !englishWord.trim() || !uzbekWord.trim()}
                className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 rounded-xl shadow-md transition flex items-center space-x-1.5"
              >
                {isSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                <span>Lug'atga qo'shish</span>
              </button>
            </div>
          </form>
        ) : (
          /* Bulk Input Form */
          <div className="p-6 space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Bir vaqtda bir nechta lug'at kiritish:
              </label>
              <p className="text-xs text-slate-400 mb-2">
                Har bir qatorda inglizcha so'z va o'zbekcha tarjimasini <code className="text-indigo-400">-</code> yoki <code className="text-indigo-400">:</code> belgisi bilan ajrating:
              </p>
              <textarea
                rows={6}
                value={bulkText}
                onChange={(e) => handleBulkTextChange(e.target.value)}
                placeholder={"apple - olma\nbook - kitob\nschool - maktab\ncomputer : kompyuter"}
                className="w-full p-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 font-mono text-xs focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="flex items-center justify-between text-xs bg-slate-800/50 p-3 rounded-xl border border-slate-700/60">
              <div className="flex items-center space-x-4">
                <span className="text-slate-300">
                  Aniqlangan so'zlar: <strong className="text-emerald-400">{bulkParsedCount} ta</strong>
                </span>
                {bulkDuplicateCount > 0 && (
                  <span className="text-amber-400">
                    Takrorlanganlar: <strong>{bulkDuplicateCount} ta</strong>
                  </span>
                )}
              </div>
              <div className="flex items-center space-x-2">
                <label className="text-slate-400">Guruh:</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="px-2 py-1 bg-slate-900 border border-slate-700 rounded text-white text-xs"
                >
                  {VOCABULARY_CATEGORIES.filter((c) => c !== 'Barchasi').map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {errorMessage && (
              <div className="p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl text-xs text-rose-300">
                {errorMessage}
              </div>
            )}

            <div className="flex items-center justify-end space-x-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition"
              >
                Bekor qilish
              </button>
              <button
                type="button"
                onClick={handleSaveBulk}
                disabled={isSaving || bulkParsedCount === 0}
                className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 rounded-xl shadow-md transition flex items-center space-x-1.5"
              >
                {isSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                <span>Barchasini qo'shish ({bulkParsedCount})</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
