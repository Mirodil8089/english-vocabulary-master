import React, { useState, useMemo } from 'react';
import {
  Search, Plus, Shuffle, Filter, ArrowUpDown, Volume2, Edit3, Trash2,
  BookOpen, Sparkles, CheckCircle2, Clock, AlertCircle, ChevronDown, ChevronUp, Layers
} from 'lucide-react';
import { WordItem, WordStatus } from '../types';
import { audioService } from '../services/audioService';
import { VOCABULARY_CATEGORIES } from '../data/initialVocabulary';

interface VocabularySectionProps {
  words: WordItem[];
  onOpenAddModal: () => void;
  onOpenEditModal: (word: WordItem) => void;
  onOpenDeleteModal: (word: WordItem) => void;
  onOpenShuffleMemorize: () => void;
}

export const VocabularySection: React.FC<VocabularySectionProps> = ({
  words,
  onOpenAddModal,
  onOpenEditModal,
  onOpenDeleteModal,
  onOpenShuffleMemorize,
}) => {
  // Filters & search
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Barchasi');
  const [statusFilter, setStatusFilter] = useState<'all' | WordStatus | 'difficult'>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'alpha_asc' | 'alpha_desc' | 'difficult'>('newest');
  const [expandedWordIds, setExpandedWordIds] = useState<Set<string>>(new Set());

  // Toggle card details
  const toggleExpand = (id: string) => {
    setExpandedWordIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  // Filter & sort logic
  const filteredWords = useMemo(() => {
    let result = [...words];

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        (w) =>
          w.english.toLowerCase().includes(q) ||
          w.uzbek.toLowerCase().includes(q) ||
          (w.exampleEn && w.exampleEn.toLowerCase().includes(q)) ||
          (w.exampleUz && w.exampleUz.toLowerCase().includes(q))
      );
    }

    // Category
    if (selectedCategory !== 'Barchasi') {
      result = result.filter((w) => w.category === selectedCategory);
    }

    // Status filter
    if (statusFilter === 'difficult') {
      result = result.filter((w) => w.difficultyScore >= 4 || w.incorrectCount > 1);
    } else if (statusFilter !== 'all') {
      result = result.filter((w) => w.status === statusFilter);
    }

    // Sort
    result.sort((a, b) => {
      if (sortBy === 'newest') {
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
      if (sortBy === 'alpha_asc') {
        return a.english.localeCompare(b.english);
      }
      if (sortBy === 'alpha_desc') {
        return b.english.localeCompare(a.english);
      }
      if (sortBy === 'difficult') {
        return b.difficultyScore - a.difficultyScore;
      }
      return 0;
    });

    return result;
  }, [words, searchQuery, selectedCategory, statusFilter, sortBy]);

  // Statistics summaries
  const totalCount = words.length;
  const newCount = words.filter((w) => w.status === 'new').length;
  const learningCount = words.filter((w) => w.status === 'learning').length;
  const masteredCount = words.filter((w) => w.status === 'mastered').length;

  return (
    <div className="space-y-6 pb-24 md:pb-12">
      {/* Top Hero Banner & Quick Actions */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-950/80 via-slate-900 to-slate-900 border border-indigo-900/40 p-6 sm:p-8 shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div>
            <div className="flex items-center space-x-2 text-indigo-400 text-xs font-bold uppercase tracking-wider mb-2">
              <Sparkles className="w-4 h-4" />
              <span>1-Bo'lim: Mening Lug'atlarim</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Shaxsiy Lug'at To'plami
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-xl">
              O'zingiz o'rganayotgan so'zlarni to'plang, ishonchli tarjima bilan tekshiring va aralashtirib yodlang.
            </p>

            {/* Quick stats pills */}
            <div className="flex flex-wrap items-center gap-3 mt-4 text-xs">
              <span className="px-3 py-1 rounded-full bg-slate-800/80 text-slate-300 border border-slate-700/60">
                Jami: <strong className="text-white">{totalCount}</strong>
              </span>
              <span className="px-3 py-1 rounded-full bg-indigo-950/50 text-indigo-300 border border-indigo-500/30">
                Yangi: <strong className="text-indigo-200">{newCount}</strong>
              </span>
              <span className="px-3 py-1 rounded-full bg-amber-950/50 text-amber-300 border border-amber-500/30">
                O'rganilmoqda: <strong className="text-amber-200">{learningCount}</strong>
              </span>
              <span className="px-3 py-1 rounded-full bg-emerald-950/50 text-emerald-300 border border-emerald-500/30">
                O'zlashtirildi: <strong className="text-emerald-200">{masteredCount}</strong>
              </span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap sm:flex-nowrap items-center gap-3">
            <button
              onClick={onOpenShuffleMemorize}
              disabled={words.length === 0}
              className="flex-1 sm:flex-initial px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 disabled:from-slate-700 disabled:to-slate-800 text-white font-semibold text-sm shadow-lg shadow-emerald-600/25 flex items-center justify-center space-x-2 transition"
            >
              <Shuffle className="w-4 h-4" />
              <span>Yodlashni boshlash</span>
            </button>

            <button
              onClick={onOpenAddModal}
              className="flex-1 sm:flex-initial px-5 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm shadow-lg shadow-indigo-600/30 flex items-center justify-center space-x-2 transition"
            >
              <Plus className="w-4 h-4" />
              <span>Lug'at qo'shish</span>
            </button>
          </div>
        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Search box */}
          <div className="md:col-span-5 relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="So'z yoki tarjimani qidirish..."
              className="w-full pl-10 pr-4 py-2 bg-slate-800/90 border border-slate-700/80 rounded-xl text-white placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
              >
                ✕
              </button>
            )}
          </div>

          {/* Category Dropdown */}
          <div className="md:col-span-4 relative">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2 bg-slate-800/90 border border-slate-700/80 rounded-xl text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 appearance-none"
            >
              {VOCABULARY_CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  Guruh: {cat}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
          </div>

          {/* Sort By */}
          <div className="md:col-span-3 relative">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full px-3 py-2 bg-slate-800/90 border border-slate-700/80 rounded-xl text-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 appearance-none"
            >
              <option value="newest">Eng yangi qo'shilgan</option>
              <option value="alpha_asc">Alifbo bo'yicha (A ➔ Z)</option>
              <option value="alpha_desc">Alifbo bo'yicha (Z ➔ A)</option>
              <option value="difficult">Eng qiyin so'zlar</option>
            </select>
            <ArrowUpDown className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
          </div>
        </div>

        {/* Status Filter Chips */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-800">
          <span className="text-xs text-slate-400 flex items-center mr-1">
            <Filter className="w-3.5 h-3.5 mr-1" /> Holat:
          </span>
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition ${
              statusFilter === 'all'
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            Barchasi ({totalCount})
          </button>
          <button
            onClick={() => setStatusFilter('new')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition ${
              statusFilter === 'new'
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            Yangi ({newCount})
          </button>
          <button
            onClick={() => setStatusFilter('learning')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition ${
              statusFilter === 'learning'
                ? 'bg-amber-600 text-white'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            O'rganilmoqda ({learningCount})
          </button>
          <button
            onClick={() => setStatusFilter('mastered')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition ${
              statusFilter === 'mastered'
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            O'zlashtirilgan ({masteredCount})
          </button>
          <button
            onClick={() => setStatusFilter('difficult')}
            className={`px-3 py-1 rounded-lg text-xs font-medium transition ${
              statusFilter === 'difficult'
                ? 'bg-rose-600 text-white'
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            Qiyin so'zlar
          </button>
        </div>
      </div>

      {/* Vocabulary Cards Grid */}
      {filteredWords.length === 0 ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-12 text-center">
          <BookOpen className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-white mb-1">Lug'at topilmadi</h3>
          <p className="text-xs text-slate-400 mb-6 max-w-sm mx-auto">
            {searchQuery
              ? `"${searchQuery}" bo'yicha hech qanday so'z topilmadi. Qidiruvni tozalang yoki yangi so'z qo'shing.`
              : "Hozircha ushbu toifada so'zlar yo'q. Birinchi so'zni qo'shing!"}
          </p>
          <button
            onClick={onOpenAddModal}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold shadow-md inline-flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Lug'at qo'shish</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredWords.map((word) => {
            const isExpanded = expandedWordIds.has(word.id);
            const statusBadgeColor =
              word.status === 'mastered'
                ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                : word.status === 'learning'
                ? 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                : 'bg-indigo-500/15 text-indigo-400 border-indigo-500/30';

            const statusText =
              word.status === 'mastered'
                ? "O'zlashtirilgan"
                : word.status === 'learning'
                ? "O'rganilmoqda"
                : 'Yangi';

            return (
              <div
                key={word.id}
                className="bg-slate-900/80 hover:bg-slate-900 border border-slate-800 hover:border-slate-700/80 rounded-2xl p-5 shadow-lg transition-all duration-200 flex flex-col justify-between group"
              >
                <div>
                  {/* Card Header: Category & Status */}
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[11px] font-semibold text-slate-400 bg-slate-800/80 px-2.5 py-0.5 rounded-full border border-slate-700/60">
                      {word.category || 'Umumiy'}
                    </span>
                    <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-full border ${statusBadgeColor}`}>
                      {statusText}
                    </span>
                  </div>

                  {/* Word and Audio */}
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center space-x-2">
                        <h3 className="text-xl font-bold text-white tracking-tight">{word.english}</h3>
                        <button
                          onClick={() => audioService.speak(word.english)}
                          className="p-1 text-slate-400 hover:text-indigo-400 hover:bg-slate-800 rounded-lg transition"
                          title="Talaffuzni tinglash"
                        >
                          <Volume2 className="w-4 h-4" />
                        </button>
                      </div>
                      {word.transcription && (
                        <span className="text-xs font-mono text-slate-400">{word.transcription}</span>
                      )}
                    </div>

                    {word.partOfSpeech && (
                      <span className="text-[11px] italic text-slate-500 font-serif">
                        {word.partOfSpeech}
                      </span>
                    )}
                  </div>

                  {/* Uzbek translation */}
                  <div className="mt-3 bg-slate-800/50 p-3 rounded-xl border border-slate-700/50">
                    <span className="text-[11px] text-slate-400 uppercase font-semibold block mb-0.5">O'zbekcha:</span>
                    <p className="text-base font-semibold text-emerald-400">{word.uzbek}</p>
                  </div>

                  {/* Optional Example Sentences */}
                  {(word.exampleEn || word.exampleUz) && (
                    <div className="mt-3">
                      <button
                        onClick={() => toggleExpand(word.id)}
                        className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center space-x-1"
                      >
                        <span>{isExpanded ? 'Misolni yashirish' : 'Misol gapni ko\'rish'}</span>
                        {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                      </button>

                      {isExpanded && (
                        <div className="mt-2 p-3 bg-slate-950/60 rounded-xl border border-slate-800 text-xs space-y-1 animate-in fade-in">
                          {word.exampleEn && <p className="text-slate-300 italic">"{word.exampleEn}"</p>}
                          {word.exampleUz && <p className="text-slate-400">"{word.exampleUz}"</p>}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Card Footer: Metadata and Edit/Delete Actions */}
                <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-500">
                  <div className="flex items-center space-x-2">
                    <span title="Takrorlangan marta">Takror: {word.timesReviewed}</span>
                    <span>•</span>
                    <span className="text-emerald-500">✓ {word.correctCount}</span>
                  </div>

                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => onOpenEditModal(word)}
                      className="p-1.5 text-slate-400 hover:text-indigo-400 hover:bg-slate-800 rounded-lg transition"
                      title="Tahrirlash"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => onOpenDeleteModal(word)}
                      className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition"
                      title="O'chirish"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Floating Telegram-Style "+" Button in Bottom Right Corner (Required by prompt) */}
      <div className="fixed bottom-20 md:bottom-8 right-6 z-40">
        <button
          onClick={onOpenAddModal}
          title="Yangi lug'at qo'shish"
          className="w-14 h-14 rounded-full bg-gradient-to-tr from-indigo-600 to-sky-500 text-white shadow-2xl shadow-indigo-600/50 flex items-center justify-center hover:scale-105 active:scale-95 transition-all group"
        >
          <Plus className="w-7 h-7 group-hover:rotate-90 transition-transform duration-200" />
        </button>
      </div>
    </div>
  );
};
