import React, { useState, useEffect } from 'react';
import { X, Check, Volume2, Loader2 } from 'lucide-react';
import { WordItem } from '../types';
import { audioService } from '../services/audioService';
import { VOCABULARY_CATEGORIES } from '../data/initialVocabulary';

interface EditWordModalProps {
  word: WordItem | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedWord: WordItem) => Promise<void>;
}

export const EditWordModal: React.FC<EditWordModalProps> = ({
  word,
  isOpen,
  onClose,
  onSave,
}) => {
  const [english, setEnglish] = useState('');
  const [uzbek, setUzbek] = useState('');
  const [transcription, setTranscription] = useState('');
  const [partOfSpeech, setPartOfSpeech] = useState('noun');
  const [category, setCategory] = useState('Kundalik hayot');
  const [exampleEn, setExampleEn] = useState('');
  const [exampleUz, setExampleUz] = useState('');
  const [status, setStatus] = useState<WordItem['status']>('new');
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (word) {
      setEnglish(word.english);
      setUzbek(word.uzbek);
      setTranscription(word.transcription || '');
      setPartOfSpeech(word.partOfSpeech || 'noun');
      setCategory(word.category || 'Kundalik hayot');
      setExampleEn(word.exampleEn || '');
      setExampleUz(word.exampleUz || '');
      setStatus(word.status || 'new');
    }
  }, [word]);

  if (!isOpen || !word) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!english.trim() || !uzbek.trim()) {
      setError('Inglizcha so\'z va o\'zbekcha tarjima to\'ldirilishi shart.');
      return;
    }

    setIsSaving(true);
    setError(null);
    try {
      await onSave({
        ...word,
        english: english.trim(),
        uzbek: uzbek.trim(),
        transcription: transcription.trim(),
        partOfSpeech: partOfSpeech.trim(),
        category,
        exampleEn: exampleEn.trim(),
        exampleUz: exampleUz.trim(),
        status,
      });
      onClose();
    } catch (err) {
      setError('Tahrirlashda xato yuz berdi: ' + (err instanceof Error ? err.message : ''));
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden my-8">
        <div className="px-6 py-4 bg-slate-800/80 border-b border-slate-700/80 flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-white">Lug'atni tahrirlash</h2>
            <p className="text-xs text-slate-400">"{word.english}" so'z ma'lumotlarini o'zgartirish</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700/60 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs text-slate-400">Inglizcha so'z:</label>
                <button
                  type="button"
                  onClick={() => audioService.speak(english)}
                  className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center"
                >
                  <Volume2 className="w-3.5 h-3.5 mr-0.5" /> Tinglash
                </button>
              </div>
              <input
                type="text"
                value={english}
                onChange={(e) => setEnglish(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white text-sm"
                required
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">O'zbekcha tarjimasi:</label>
              <input
                type="text"
                value={uzbek}
                onChange={(e) => setUzbek(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white text-sm"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs text-slate-400 mb-1">Transkripsiya:</label>
              <input
                type="text"
                value={transcription}
                onChange={(e) => setTranscription(e.target.value)}
                className="w-full px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-xs"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">So'z turkumi:</label>
              <select
                value={partOfSpeech}
                onChange={(e) => setPartOfSpeech(e.target.value)}
                className="w-full px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-xs"
              >
                <option value="noun">Noun (Ot)</option>
                <option value="verb">Verb (Fe'l)</option>
                <option value="adjective">Adjective (Sifat)</option>
                <option value="adverb">Adverb (Ravish)</option>
                <option value="phrase">Phrase (Ibora)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">O'zlashtirish holati:</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as WordItem['status'])}
                className="w-full px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-xs"
              >
                <option value="new">Yangi so'z</option>
                <option value="learning">O'rganilmoqda</option>
                <option value="mastered">O'zlashtirilgan</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">Guruh / Kategoriya:</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-xs"
            >
              {VOCABULARY_CATEGORIES.filter((c) => c !== 'Barchasi').map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-2 pt-2 border-t border-slate-800">
            <div>
              <label className="block text-xs text-slate-400 mb-1">Misol gap (Inglizcha):</label>
              <input
                type="text"
                value={exampleEn}
                onChange={(e) => setExampleEn(e.target.value)}
                className="w-full px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-xs"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1">Misol gap tarjimasi (O'zbekcha):</label>
              <input
                type="text"
                value={exampleUz}
                onChange={(e) => setExampleUz(e.target.value)}
                className="w-full px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-xs"
              />
            </div>
          </div>

          {error && (
            <div className="p-3 bg-rose-500/15 border border-rose-500/30 rounded-xl text-xs text-rose-300">
              {error}
            </div>
          )}

          <div className="flex items-center justify-end space-x-3 pt-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 rounded-xl transition"
            >
              Bekor qilish
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-xl shadow-md transition flex items-center space-x-1.5"
            >
              {isSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
              <span>Saqlash</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
