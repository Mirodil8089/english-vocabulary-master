// Offline fallback dictionary for instant, reliable English-Uzbek translations
const OFFLINE_DICTIONARY_EN_UZ: Record<string, { uz: string; pos: string; phonetic: string; exampleEn?: string; exampleUz?: string }> = {
  'school': { uz: 'maktab', pos: 'noun', phonetic: '/skuːl/', exampleEn: 'He walks to school every day.', exampleUz: 'U har kuni maktabga boradi.' },
  'book': { uz: 'kitob', pos: 'noun', phonetic: '/bʊk/', exampleEn: 'I am reading an interesting book.', exampleUz: 'Men qiziqarli kitob o\'qiyapman.' },
  'student': { uz: 'talaba, o\'quvchi', pos: 'noun', phonetic: '/ˈstjuːdnt/', exampleEn: 'He is a university student.', exampleUz: 'U universitet talabasi.' },
  'teacher': { uz: 'o\'qituvchi, ustoz', pos: 'noun', phonetic: '/ˈtiːtʃə/', exampleEn: 'The teacher explained the lesson.', exampleUz: 'O\'qituvchi darsni tushuntirdi.' },
  'water': { uz: 'suv', pos: 'noun', phonetic: '/ˈwɔːtə/', exampleEn: 'Drink plenty of water.', exampleUz: 'Ko\'p suv iching.' },
  'apple': { uz: 'olma', pos: 'noun', phonetic: '/ˈæpl/', exampleEn: 'An apple a day keeps the doctor away.', exampleUz: 'Kuniga bir olma sog\'liq garovi.' },
  'car': { uz: 'avtomobil, mashina', pos: 'noun', phonetic: '/kɑː/', exampleEn: 'He bought a new car.', exampleUz: 'U yangi mashina sotib oldi.' },
  'house': { uz: 'uy, bino', pos: 'noun', phonetic: '/haʊs/', exampleEn: 'Their house is near the park.', exampleUz: 'Ularning uyi bog\' yonida joylashgan.' },
  'home': { uz: 'uy, vatan', pos: 'noun', phonetic: '/həʊm/', exampleEn: 'Welcome home!', exampleUz: 'Uyga xush kelibsiz!' },
  'friend': { uz: 'do\'st, o\'rtoq', pos: 'noun', phonetic: '/frend/', exampleEn: 'A friend in need is a friend indeed.', exampleUz: 'Haqiqiy do\'st kunda bilinar.' },
  'family': { uz: 'oila', pos: 'noun', phonetic: '/ˈfæməli/', exampleEn: 'Family is the most important thing.', exampleUz: 'Oila eng muhim narsadir.' },
  'work': { uz: 'ish, mehnat qilmoq', pos: 'noun/verb', phonetic: '/wɜːk/', exampleEn: 'Hard work pays off.', exampleUz: 'Mashaqqatli mehnat o\'z samarasini beradi.' },
  'study': { uz: 'o\'rganmoq, tahsil olmoq', pos: 'verb', phonetic: '/ˈstʌdi/', exampleEn: 'She studies English hard.', exampleUz: 'U ingliz tilini jiddiy o\'rganmoqda.' },
  'learn': { uz: 'o\'rganmoq, yod olmoq', pos: 'verb', phonetic: '/lɜːn/', exampleEn: 'Never stop learning.', exampleUz: 'O\'rganishdan hech qachon to\'xtamang.' },
  'language': { uz: 'til', pos: 'noun', phonetic: '/ˈlæŋɡwɪdʒ/', exampleEn: 'English is an international language.', exampleUz: 'Ingliz tili xalqaro til hisoblanadi.' },
  'knowledge': { uz: 'bilim, ma\'lumot', pos: 'noun', phonetic: '/ˈnɒlɪdʒ/', exampleEn: 'Knowledge is power.', exampleUz: 'Bilim — kuchdir.' },
  'diligent': { uz: 'mehnatkash, tirishqoq', pos: 'adjective', phonetic: '/ˈdɪlɪdʒənt/', exampleEn: 'Diligent effort leads to success.', exampleUz: 'Tirishqoqlik muvaffaqiyatga olib boradi.' },
  'opportunity': { uz: 'imkoniyat, fursat', pos: 'noun', phonetic: '/ˌɒpəˈtjuːnəti/', exampleEn: 'Take this opportunity!', exampleUz: 'Ushbu imkoniyatdan foydalaning!' },
  'achieve': { uz: 'erishmoq, zabt etmoq', pos: 'verb', phonetic: '/əˈtʃiːv/', exampleEn: 'You will achieve greatness.', exampleUz: 'Siz buyuklikka erishasiz.' },
  'goal': { uz: 'maqsad, marra', pos: 'noun', phonetic: '/ɡəʊl/', exampleEn: 'Set high goals for yourself.', exampleUz: 'O\'zingiz uchun yuksak maqsadlar qo\'ying.' },
  'success': { uz: 'muvaffaqiyat, g\'alaba', pos: 'noun', phonetic: '/səkˈses/', exampleEn: 'Success requires dedication.', exampleUz: 'Muvaffaqiyat fidoyilikni talab qiladi.' },
  'dream': { uz: 'orzu, tush ko\'rmoq', pos: 'noun/verb', phonetic: '/driːm/', exampleEn: 'Follow your dreams.', exampleUz: 'Orzularingiz tomon intiling.' },
  'wisdom': { uz: 'donolik, aql-idrok', pos: 'noun', phonetic: '/ˈwɪzdəm/', exampleEn: 'Wisdom comes with experience.', exampleUz: 'Donolik tajriba bilan keladi.' },
  'time': { uz: 'vaqt, payt', pos: 'noun', phonetic: '/taɪm/', exampleEn: 'Time is the most valuable resource.', exampleUz: 'Vaqt eng qimmatli boylikdir.' },
  'world': { uz: 'dunyo, olam', pos: 'noun', phonetic: '/wɜːld/', exampleEn: 'Travel around the world.', exampleUz: 'Dunyo bo\'ylab sayohat qiling.' },
  'life': { uz: 'hayot, turmush', pos: 'noun', phonetic: '/laɪf/', exampleEn: 'Life is full of surprises.', exampleUz: 'Hayot kutilmagan sovg\'alarga boy.' },
  'freedom': { uz: 'erkinlik, ozodlik', pos: 'noun', phonetic: '/ˈfriːdəm/', exampleEn: 'Freedom of speech is vital.', exampleUz: 'So\'z erkinligi juda muhim.' },
  'peace': { uz: 'tinchlik, osoyishtalik', pos: 'noun', phonetic: '/piːs/', exampleEn: 'We all pray for peace.', exampleUz: 'Biz hammamiz tinchlik tilaymiz.' },
  'computer': { uz: 'kompyuter, hisoblagich', pos: 'noun', phonetic: '/kəmˈpjuːtə/', exampleEn: 'I use a computer for work.', exampleUz: 'Men ish uchun kompyuterdan foydalanaman.' },
  'develop': { uz: 'rivojlantirmoq, taraqqiy etmoq', pos: 'verb', phonetic: '/dɪˈveləp/', exampleEn: 'Develop your skills daily.', exampleUz: 'Har kuni ko\'nikmalaringizni rivojlantiring.' },
};

// Build reverse dictionary Uzbek -> English
const OFFLINE_DICTIONARY_UZ_EN: Record<string, { en: string; pos: string; phonetic: string; exampleEn?: string; exampleUz?: string }> = {};
Object.entries(OFFLINE_DICTIONARY_EN_UZ).forEach(([en, data]) => {
  const uzKeys = data.uz.split(',').map((k) => k.trim().toLowerCase());
  uzKeys.forEach((k) => {
    OFFLINE_DICTIONARY_UZ_EN[k] = {
      en,
      pos: data.pos,
      phonetic: data.phonetic,
      exampleEn: data.exampleEn,
      exampleUz: data.exampleUz,
    };
  });
});

export interface TranslationResult {
  translatedText: string;
  sourceText: string;
  sourceLang: 'en' | 'uz';
  targetLang: 'uz' | 'en';
  phonetic?: string;
  partOfSpeech?: string;
  exampleEn?: string;
  exampleUz?: string;
  sourceProvider: 'dictionary_db' | 'mymemory_api' | 'server_ai' | 'user_manual';
}

class TranslationService {
  /**
   * Translate text between English and Uzbek
   */
  public async translate(
    text: string,
    direction: 'en_to_uz' | 'uz_to_en'
  ): Promise<TranslationResult> {
    const cleaned = text.trim();
    if (!cleaned) {
      return {
        translatedText: '',
        sourceText: text,
        sourceLang: direction === 'en_to_uz' ? 'en' : 'uz',
        targetLang: direction === 'en_to_uz' ? 'uz' : 'en',
        sourceProvider: 'user_manual',
      };
    }

    const norm = cleaned.toLowerCase();

    // 1. Check quick local offline dictionary
    if (direction === 'en_to_uz' && OFFLINE_DICTIONARY_EN_UZ[norm]) {
      const match = OFFLINE_DICTIONARY_EN_UZ[norm];
      return {
        translatedText: match.uz,
        sourceText: cleaned,
        sourceLang: 'en',
        targetLang: 'uz',
        phonetic: match.phonetic,
        partOfSpeech: match.pos,
        exampleEn: match.exampleEn,
        exampleUz: match.exampleUz,
        sourceProvider: 'dictionary_db',
      };
    } else if (direction === 'uz_to_en' && OFFLINE_DICTIONARY_UZ_EN[norm]) {
      const match = OFFLINE_DICTIONARY_UZ_EN[norm];
      return {
        translatedText: match.en,
        sourceText: cleaned,
        sourceLang: 'uz',
        targetLang: 'en',
        phonetic: match.phonetic,
        partOfSpeech: match.pos,
        exampleEn: match.exampleEn,
        exampleUz: match.exampleUz,
        sourceProvider: 'dictionary_db',
      };
    }

    // 2. Try backend API proxy if running
    try {
      const serverRes = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: cleaned,
          sourceLang: direction === 'en_to_uz' ? 'en' : 'uz',
          targetLang: direction === 'en_to_uz' ? 'uz' : 'en',
        }),
      });

      if (serverRes.ok) {
        const data = await serverRes.json();
        if (data && data.translatedText) {
          return {
            translatedText: data.translatedText,
            sourceText: cleaned,
            sourceLang: direction === 'en_to_uz' ? 'en' : 'uz',
            targetLang: direction === 'en_to_uz' ? 'uz' : 'en',
            phonetic: data.phonetic,
            partOfSpeech: data.partOfSpeech,
            exampleEn: data.exampleEn,
            exampleUz: data.exampleUz,
            sourceProvider: 'server_ai',
          };
        }
      }
    } catch {
      // Server not reachable or route not active, continue to public fallback
    }

    // 3. Try direct MyMemory Translation API
    try {
      const langpair = direction === 'en_to_uz' ? 'en|uz' : 'uz|en';
      const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(cleaned)}&langpair=${langpair}`;
      const response = await fetch(url);
      if (response.ok) {
        const resData = await response.json();
        const translation = resData?.responseData?.translatedText;
        if (translation && translation !== cleaned && !translation.includes('MYMEMORY WARNING')) {
          // If english word, let's fetch phonetic info from free dictionary API
          let phonetic = '';
          let partOfSpeech = '';
          let exampleEn = '';

          if (direction === 'en_to_uz') {
            const dictInfo = await this.fetchFreeDictionaryInfo(cleaned);
            phonetic = dictInfo.phonetic || '';
            partOfSpeech = dictInfo.partOfSpeech || '';
            exampleEn = dictInfo.example || '';
          }

          return {
            translatedText: translation.toLowerCase(),
            sourceText: cleaned,
            sourceLang: direction === 'en_to_uz' ? 'en' : 'uz',
            targetLang: direction === 'en_to_uz' ? 'uz' : 'en',
            phonetic,
            partOfSpeech,
            exampleEn,
            sourceProvider: 'mymemory_api',
          };
        }
      }
    } catch (e) {
      console.warn('MyMemory API xatoligi:', e);
    }

    // 4. Fallback: if en_to_uz, fetch dictionary info for phonetic/example, leave translation for user edit
    let fallbackPhonetic = '';
    let fallbackPos = '';
    let fallbackEx = '';
    if (direction === 'en_to_uz') {
      const dictInfo = await this.fetchFreeDictionaryInfo(cleaned);
      fallbackPhonetic = dictInfo.phonetic || '';
      fallbackPos = dictInfo.partOfSpeech || '';
      fallbackEx = dictInfo.example || '';
    }

    return {
      translatedText: '',
      sourceText: cleaned,
      sourceLang: direction === 'en_to_uz' ? 'en' : 'uz',
      targetLang: direction === 'en_to_uz' ? 'uz' : 'en',
      phonetic: fallbackPhonetic,
      partOfSpeech: fallbackPos,
      exampleEn: fallbackEx,
      sourceProvider: 'user_manual',
    };
  }

  /**
   * Fetch phonetic and definitions from public FreeDictionary API
   */
  public async fetchFreeDictionaryInfo(word: string): Promise<{
    phonetic?: string;
    partOfSpeech?: string;
    example?: string;
    definitions?: string[];
  }> {
    try {
      const url = `https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word.toLowerCase().trim())}`;
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        if (Array.isArray(data) && data.length > 0) {
          const entry = data[0];
          const phonetic = entry.phonetic || (entry.phonetics && entry.phonetics[0]?.text) || '';
          const meaning = entry.meanings?.[0];
          const partOfSpeech = meaning?.partOfSpeech || '';
          const defObj = meaning?.definitions?.[0];
          const example = defObj?.example || '';
          const definitions = meaning?.definitions?.map((d: { definition: string }) => d.definition).slice(0, 3) || [];

          return {
            phonetic,
            partOfSpeech,
            example,
            definitions,
          };
        }
      }
    } catch {
      // ignore
    }
    return {};
  }
}

export const translationService = new TranslationService();
