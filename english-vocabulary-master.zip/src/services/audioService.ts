class AudioService {
  private synth: SpeechSynthesis | null = null;
  private voice: SpeechSynthesisVoice | null = null;
  private isMuted: boolean = false;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
      this.initVoice();
      if (speechSynthesis.onvoiceschanged !== undefined) {
        speechSynthesis.onvoiceschanged = () => this.initVoice();
      }
    }
  }

  private initVoice() {
    if (!this.synth) return;
    const voices = this.synth.getVoices();
    // Prefer English (US or GB)
    const enVoice = voices.find(
      (v) => (v.lang === 'en-US' || v.lang === 'en-GB' || v.lang.startsWith('en')) && v.name.includes('Google')
    ) || voices.find((v) => v.lang.startsWith('en')) || voices[0];

    if (enVoice) {
      this.voice = enVoice;
    }
  }

  public speak(text: string, rate: number = 0.9): Promise<void> {
    return new Promise((resolve) => {
      if (this.isMuted || !this.synth) {
        resolve();
        return;
      }

      try {
        this.synth.cancel(); // Stop any pending speech
        const utterance = new SpeechSynthesisUtterance(text);
        if (this.voice) {
          utterance.voice = this.voice;
        }
        utterance.lang = 'en-US';
        utterance.rate = rate; // 0.9 is natural yet clear for language learners
        utterance.pitch = 1.0;

        utterance.onend = () => resolve();
        utterance.onerror = () => resolve();

        this.synth.speak(utterance);
      } catch (err) {
        console.warn('Ovoz chiqarishda xato:', err);
        resolve();
      }
    });
  }

  public stop() {
    if (this.synth) {
      this.synth.cancel();
    }
  }
}

export const audioService = new AudioService();
