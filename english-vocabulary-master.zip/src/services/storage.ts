import { WordItem, QuizSessionRecord, SearchHistoryItem, DailyGoalStats } from '../types';
import { INITIAL_VOCABULARY } from '../data/initialVocabulary';

const DB_NAME = 'EnglishVocabMasterDB';
const DB_VERSION = 2;
const STORE_WORDS = 'vocabulary_words';
const STORE_QUIZ = 'quiz_sessions';
const STORE_SEARCH = 'search_history';
const STORE_SETTINGS = 'app_settings';

const LOCAL_STORAGE_KEY_WORDS = 'evm_words_backup';
const LOCAL_STORAGE_KEY_QUIZ = 'evm_quiz_backup';
const LOCAL_STORAGE_KEY_SEARCH = 'evm_search_backup';
const LOCAL_STORAGE_KEY_PROFILE = 'evm_current_profile';

class StorageService {
  private dbPromise: Promise<IDBDatabase | null> | null = null;
  private currentUserId: string = 'asosiy_foydalanuvchi';

  constructor() {
    this.initUserId();
  }

  private initUserId() {
    if (typeof window !== 'undefined') {
      const savedUser = localStorage.getItem(LOCAL_STORAGE_KEY_PROFILE);
      if (savedUser) {
        this.currentUserId = savedUser;
      }
    }
  }

  public getUserId(): string {
    return this.currentUserId;
  }

  public setUserId(username: string): void {
    this.currentUserId = username.trim() || 'asosiy_foydalanuvchi';
    if (typeof window !== 'undefined') {
      localStorage.setItem(LOCAL_STORAGE_KEY_PROFILE, this.currentUserId);
    }
  }

  private openDatabase(): Promise<IDBDatabase | null> {
    if (typeof window === 'undefined' || !('indexedDB' in window)) {
      return Promise.resolve(null);
    }

    if (this.dbPromise) {
      return this.dbPromise;
    }

    this.dbPromise = new Promise((resolve) => {
      try {
        const request = indexedDB.open(DB_NAME, DB_VERSION);

        request.onupgradeneeded = (event) => {
          const db = (event.target as IDBOpenDBRequest).result;
          if (!db.objectStoreNames.contains(STORE_WORDS)) {
            const wordStore = db.createObjectStore(STORE_WORDS, { keyPath: 'id' });
            wordStore.createIndex('english', 'english', { unique: false });
            wordStore.createIndex('status', 'status', { unique: false });
            wordStore.createIndex('category', 'category', { unique: false });
          }
          if (!db.objectStoreNames.contains(STORE_QUIZ)) {
            db.createObjectStore(STORE_QUIZ, { keyPath: 'id' });
          }
          if (!db.objectStoreNames.contains(STORE_SEARCH)) {
            db.createObjectStore(STORE_SEARCH, { keyPath: 'id' });
          }
          if (!db.objectStoreNames.contains(STORE_SETTINGS)) {
            db.createObjectStore(STORE_SETTINGS, { keyPath: 'key' });
          }
        };

        request.onsuccess = () => {
          resolve(request.result);
        };

        request.onerror = (err) => {
          console.warn('IndexedDB ochishda xatolik, localStorage ga o\'tiladi:', err);
          resolve(null);
        };
      } catch (e) {
        console.warn('IndexedDB qo\'llab-quvvatlanmadi:', e);
        resolve(null);
      }
    });

    return this.dbPromise;
  }

  // WORDS CRUD
  public async getAllWords(): Promise<WordItem[]> {
    const db = await this.openDatabase();
    if (!db) {
      return this.getWordsFromLocalStorage();
    }

    return new Promise((resolve) => {
      try {
        const transaction = db.transaction(STORE_WORDS, 'readonly');
        const store = transaction.objectStore(STORE_WORDS);
        const request = store.getAll();

        request.onsuccess = () => {
          const words = request.result as WordItem[];
          if (!words || words.length === 0) {
            // First time initialization with seed data
            const seeds = INITIAL_VOCABULARY;
            this.saveWordsBulk(seeds).then(() => resolve(seeds));
          } else {
            // Backup to local storage for extra safety
            this.backupWordsToLocalStorage(words);
            resolve(words);
          }
        };

        request.onerror = () => {
          resolve(this.getWordsFromLocalStorage());
        };
      } catch (err) {
        console.error('So\'zlarni olishda xato:', err);
        resolve(this.getWordsFromLocalStorage());
      }
    });
  }

  public async addWord(word: Omit<WordItem, 'id' | 'createdAt' | 'updatedAt' | 'timesReviewed' | 'correctCount' | 'incorrectCount' | 'difficultyScore' | 'status'> & { status?: WordItem['status'] }): Promise<WordItem> {
    const newWord: WordItem = {
      ...word,
      id: 'word_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status: word.status || 'new',
      timesReviewed: 0,
      correctCount: 0,
      incorrectCount: 0,
      difficultyScore: 3,
    };

    const db = await this.openDatabase();
    if (!db) {
      const words = this.getWordsFromLocalStorage();
      words.unshift(newWord);
      this.backupWordsToLocalStorage(words);
      return newWord;
    }

    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_WORDS, 'readwrite');
      const store = transaction.objectStore(STORE_WORDS);
      const request = store.add(newWord);

      request.onsuccess = () => {
        this.backupWordToLocal(newWord);
        resolve(newWord);
      };

      request.onerror = (e) => {
        reject(e);
      };
    });
  }

  public async updateWord(word: WordItem): Promise<WordItem> {
    const updated: WordItem = {
      ...word,
      updatedAt: new Date().toISOString(),
    };

    const db = await this.openDatabase();
    if (!db) {
      const words = this.getWordsFromLocalStorage();
      const idx = words.findIndex((w) => w.id === updated.id);
      if (idx !== -1) {
        words[idx] = updated;
        this.backupWordsToLocalStorage(words);
      }
      return updated;
    }

    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_WORDS, 'readwrite');
      const store = transaction.objectStore(STORE_WORDS);
      const request = store.put(updated);

      request.onsuccess = () => {
        resolve(updated);
      };

      request.onerror = (e) => {
        reject(e);
      };
    });
  }

  public async deleteWord(id: string): Promise<boolean> {
    const db = await this.openDatabase();
    if (!db) {
      const words = this.getWordsFromLocalStorage().filter((w) => w.id !== id);
      this.backupWordsToLocalStorage(words);
      return true;
    }

    return new Promise((resolve) => {
      const transaction = db.transaction(STORE_WORDS, 'readwrite');
      const store = transaction.objectStore(STORE_WORDS);
      const request = store.delete(id);

      request.onsuccess = () => {
        // Also clean up localStorage backup
        const words = this.getWordsFromLocalStorage().filter((w) => w.id !== id);
        this.backupWordsToLocalStorage(words);
        resolve(true);
      };

      request.onerror = () => {
        resolve(false);
      };
    });
  }

  public async saveWordsBulk(wordsList: WordItem[]): Promise<void> {
    const db = await this.openDatabase();
    this.backupWordsToLocalStorage(wordsList);

    if (!db) return;

    return new Promise((resolve) => {
      const transaction = db.transaction(STORE_WORDS, 'readwrite');
      const store = transaction.objectStore(STORE_WORDS);

      for (const w of wordsList) {
        store.put(w);
      }

      transaction.oncomplete = () => {
        resolve();
      };
    });
  }

  public async recordReview(wordId: string, known: boolean): Promise<WordItem | null> {
    const words = await this.getAllWords();
    const target = words.find((w) => w.id === wordId);
    if (!target) return null;

    target.timesReviewed += 1;
    target.lastReviewedAt = new Date().toISOString();

    if (known) {
      target.correctCount += 1;
      target.difficultyScore = Math.max(1, target.difficultyScore - 1);
      // If correct 3 times consecutively or >= 3 total with high accuracy
      if (target.correctCount >= 3 && target.correctCount / target.timesReviewed >= 0.7) {
        target.status = 'mastered';
      } else {
        target.status = 'learning';
      }
    } else {
      target.incorrectCount += 1;
      target.difficultyScore = Math.min(5, target.difficultyScore + 1);
      target.status = 'learning';
    }

    await this.updateWord(target);
    return target;
  }

  // QUIZ & SESSIONS
  public async saveQuizSession(session: Omit<QuizSessionRecord, 'id' | 'timestamp'>): Promise<QuizSessionRecord> {
    const fullSession: QuizSessionRecord = {
      ...session,
      id: 'quiz_' + Date.now(),
      timestamp: new Date().toISOString(),
    };

    const db = await this.openDatabase();
    if (!db) {
      const list = this.getQuizHistoryLocal();
      list.unshift(fullSession);
      localStorage.setItem(LOCAL_STORAGE_KEY_QUIZ, JSON.stringify(list.slice(0, 50)));
      return fullSession;
    }

    return new Promise((resolve) => {
      const transaction = db.transaction(STORE_QUIZ, 'readwrite');
      const store = transaction.objectStore(STORE_QUIZ);
      store.add(fullSession);
      transaction.oncomplete = () => {
        const list = this.getQuizHistoryLocal();
        list.unshift(fullSession);
        localStorage.setItem(LOCAL_STORAGE_KEY_QUIZ, JSON.stringify(list.slice(0, 50)));
        resolve(fullSession);
      };
    });
  }

  public async getQuizHistory(): Promise<QuizSessionRecord[]> {
    const db = await this.openDatabase();
    if (!db) return this.getQuizHistoryLocal();

    return new Promise((resolve) => {
      const transaction = db.transaction(STORE_QUIZ, 'readonly');
      const store = transaction.objectStore(STORE_QUIZ);
      const request = store.getAll();

      request.onsuccess = () => {
        const results = (request.result as QuizSessionRecord[]) || [];
        results.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        resolve(results);
      };

      request.onerror = () => {
        resolve(this.getQuizHistoryLocal());
      };
    });
  }

  // SEARCH HISTORY
  public async getSearchHistory(): Promise<SearchHistoryItem[]> {
    const db = await this.openDatabase();
    if (!db) return this.getSearchHistoryLocal();

    return new Promise((resolve) => {
      const transaction = db.transaction(STORE_SEARCH, 'readonly');
      const store = transaction.objectStore(STORE_SEARCH);
      const request = store.getAll();

      request.onsuccess = () => {
        const items = (request.result as SearchHistoryItem[]) || [];
        items.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        resolve(items.slice(0, 30));
      };

      request.onerror = () => {
        resolve(this.getSearchHistoryLocal());
      };
    });
  }

  public async addSearchHistory(query: string, type: 'word' | 'book' | 'phrase', resultsCount: number): Promise<void> {
    if (!query.trim()) return;
    const item: SearchHistoryItem = {
      id: 'srch_' + Date.now(),
      query: query.trim(),
      type,
      timestamp: new Date().toISOString(),
      resultsCount,
    };

    const currentLocal = this.getSearchHistoryLocal().filter(
      (h) => h.query.toLowerCase() !== query.toLowerCase()
    );
    currentLocal.unshift(item);
    localStorage.setItem(LOCAL_STORAGE_KEY_SEARCH, JSON.stringify(currentLocal.slice(0, 30)));

    const db = await this.openDatabase();
    if (!db) return;

    const transaction = db.transaction(STORE_SEARCH, 'readwrite');
    const store = transaction.objectStore(STORE_SEARCH);
    store.put(item);
  }

  public async clearSearchHistory(): Promise<void> {
    localStorage.removeItem(LOCAL_STORAGE_KEY_SEARCH);
    const db = await this.openDatabase();
    if (!db) return;

    const transaction = db.transaction(STORE_SEARCH, 'readwrite');
    const store = transaction.objectStore(STORE_SEARCH);
    store.clear();
  }

  // EXPORT & IMPORT
  public async exportJSON(): Promise<string> {
    const words = await this.getAllWords();
    const quizHistory = await this.getQuizHistory();
    const data = {
      appName: 'English Vocabulary Master',
      version: '1.0',
      exportedAt: new Date().toISOString(),
      userId: this.currentUserId,
      totalWords: words.length,
      words,
      quizHistory,
    };
    return JSON.stringify(data, null, 2);
  }

  public async importJSON(jsonStr: string): Promise<{ importedCount: number; duplicateCount: number }> {
    try {
      const parsed = JSON.parse(jsonStr);
      const incomingWords: WordItem[] = Array.isArray(parsed) ? parsed : (parsed.words || []);
      if (!Array.isArray(incomingWords)) {
        throw new Error('Noto\'g\'ri fayl formati');
      }

      const existingWords = await this.getAllWords();
      const existingMap = new Map<string, WordItem>();
      existingWords.forEach((w) => existingMap.set(w.english.toLowerCase().trim(), w));

      let importedCount = 0;
      let duplicateCount = 0;

      for (const w of incomingWords) {
        if (!w.english || !w.uzbek) continue;
        const normalized = w.english.toLowerCase().trim();
        if (existingMap.has(normalized)) {
          duplicateCount++;
        } else {
          const newWord: WordItem = {
            id: 'import_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
            english: w.english.trim(),
            uzbek: w.uzbek.trim(),
            transcription: w.transcription || '',
            partOfSpeech: w.partOfSpeech || 'noun',
            exampleEn: w.exampleEn || '',
            exampleUz: w.exampleUz || '',
            category: w.category || 'Umumiy',
            tags: Array.isArray(w.tags) ? w.tags : [],
            createdAt: w.createdAt || new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            status: w.status || 'new',
            timesReviewed: w.timesReviewed || 0,
            correctCount: w.correctCount || 0,
            incorrectCount: w.incorrectCount || 0,
            difficultyScore: w.difficultyScore || 3,
          };
          existingWords.push(newWord);
          existingMap.set(normalized, newWord);
          importedCount++;
        }
      }

      await this.saveWordsBulk(existingWords);
      return { importedCount, duplicateCount };
    } catch (e) {
      throw new Error('JSON faylni o\'qishda xatolik: ' + (e instanceof Error ? e.message : 'Noma\'lum xatolik'));
    }
  }

  public async exportCSV(): Promise<string> {
    const words = await this.getAllWords();
    const headers = ['English', 'Uzbek', 'Transcription', 'PartOfSpeech', 'Category', 'ExampleEn', 'ExampleUz', 'Status'];
    const rows = words.map((w) => [
      `"${(w.english || '').replace(/"/g, '""')}"`,
      `"${(w.uzbek || '').replace(/"/g, '""')}"`,
      `"${(w.transcription || '').replace(/"/g, '""')}"`,
      `"${(w.partOfSpeech || '').replace(/"/g, '""')}"`,
      `"${(w.category || '').replace(/"/g, '""')}"`,
      `"${(w.exampleEn || '').replace(/"/g, '""')}"`,
      `"${(w.exampleUz || '').replace(/"/g, '""')}"`,
      `"${(w.status || 'new').replace(/"/g, '""')}"`,
    ]);
    return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  }

  public async importCSV(csvStr: string): Promise<{ importedCount: number; duplicateCount: number }> {
    const lines = csvStr.split('\n').filter((l) => l.trim().length > 0);
    if (lines.length <= 1) return { importedCount: 0, duplicateCount: 0 };

    const existingWords = await this.getAllWords();
    const existingMap = new Map<string, WordItem>();
    existingWords.forEach((w) => existingMap.set(w.english.toLowerCase().trim(), w));

    let importedCount = 0;
    let duplicateCount = 0;

    // Skip header line
    for (let i = 1; i < lines.length; i++) {
      const line = lines[i];
      // Simple CSV regex parse
      const regex = /(?:,|\n|^)("(?:(?:"")*[^"]*)*"|[^",\n]*|(?:\n|$))/g;
      const matches: string[] = [];
      let match;
      while ((match = regex.exec(line)) !== null && matches.length < 8) {
        let val = match[1] || '';
        if (val.startsWith('"') && val.endsWith('"')) {
          val = val.substring(1, val.length - 1).replace(/""/g, '"');
        }
        matches.push(val.trim());
      }

      const [english, uzbek, transcription, partOfSpeech, category, exampleEn, exampleUz] = matches;
      if (!english || !uzbek) continue;

      const norm = english.toLowerCase().trim();
      if (existingMap.has(norm)) {
        duplicateCount++;
      } else {
        const item: WordItem = {
          id: 'csv_' + Date.now() + '_' + i,
          english: english.trim(),
          uzbek: uzbek.trim(),
          transcription: transcription || '',
          partOfSpeech: partOfSpeech || 'noun',
          category: category || 'Umumiy',
          exampleEn: exampleEn || '',
          exampleUz: exampleUz || '',
          tags: [],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          status: 'new',
          timesReviewed: 0,
          correctCount: 0,
          incorrectCount: 0,
          difficultyScore: 3,
        };
        existingWords.push(item);
        existingMap.set(norm, item);
        importedCount++;
      }
    }

    await this.saveWordsBulk(existingWords);
    return { importedCount, duplicateCount };
  }

  public async resetAllToSeed(): Promise<void> {
    await this.saveWordsBulk(INITIAL_VOCABULARY);
    localStorage.removeItem(LOCAL_STORAGE_KEY_QUIZ);
  }

  // LOCAL STORAGE FALLBACK HELPERS
  private getWordsFromLocalStorage(): WordItem[] {
    if (typeof window === 'undefined') return INITIAL_VOCABULARY;
    try {
      const item = localStorage.getItem(LOCAL_STORAGE_KEY_WORDS);
      if (!item) {
        this.backupWordsToLocalStorage(INITIAL_VOCABULARY);
        return INITIAL_VOCABULARY;
      }
      return JSON.parse(item) as WordItem[];
    } catch {
      return INITIAL_VOCABULARY;
    }
  }

  private backupWordsToLocalStorage(words: WordItem[]): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY_WORDS, JSON.stringify(words));
    } catch (e) {
      console.warn('LocalStorage ga yozib bo\'lmadi:', e);
    }
  }

  private backupWordToLocal(word: WordItem): void {
    const list = this.getWordsFromLocalStorage();
    const idx = list.findIndex((w) => w.id === word.id);
    if (idx !== -1) {
      list[idx] = word;
    } else {
      list.unshift(word);
    }
    this.backupWordsToLocalStorage(list);
  }

  private getQuizHistoryLocal(): QuizSessionRecord[] {
    if (typeof window === 'undefined') return [];
    try {
      const item = localStorage.getItem(LOCAL_STORAGE_KEY_QUIZ);
      return item ? JSON.parse(item) : [];
    } catch {
      return [];
    }
  }

  private getSearchHistoryLocal(): SearchHistoryItem[] {
    if (typeof window === 'undefined') return [];
    try {
      const item = localStorage.getItem(LOCAL_STORAGE_KEY_SEARCH);
      return item ? JSON.parse(item) : [];
    } catch {
      return [];
    }
  }
}

export const storageService = new StorageService();
