import { WithdomSearchResult, WithdomDefinition, WithdomBookExcerpt } from '../types';
import { translationService } from './translationService';

// Classic public domain literature quotes for authentic in-app book excerpts
const CLASSIC_LITERATURE_CORPUS: Array<{
  bookTitle: string;
  author: string;
  year: string;
  passage: string;
  keywords: string[];
  sourceUrl: string;
}> = [
  {
    bookTitle: 'The Adventures of Sherlock Holmes',
    author: 'Arthur Conan Doyle',
    year: '1892',
    passage: 'It is a capital mistake to theorize before one has data. Insensibly one begins to twist facts to suit theories, instead of theories to suit facts.',
    keywords: ['mistake', 'data', 'fact', 'theorize', 'theory', 'knowledge', 'study', 'work'],
    sourceUrl: 'https://www.gutenberg.org/ebooks/1661',
  },
  {
    bookTitle: 'Pride and Prejudice',
    author: 'Jane Austen',
    year: '1813',
    passage: 'I declare after all there is no enjoyment like reading! How much sooner one tires of any thing than of a book! When I have a house of my own, I shall be miserable if I have not an excellent library.',
    keywords: ['book', 'reading', 'house', 'library', 'enjoyment', 'school', 'learn', 'friend'],
    sourceUrl: 'https://www.gutenberg.org/ebooks/1342',
  },
  {
    bookTitle: 'Alice\'s Adventures in Wonderland',
    author: 'Lewis Carroll',
    year: '1865',
    passage: 'Begin at the beginning, the King said gravely, and go on till you come to the end: then stop.',
    keywords: ['begin', 'king', 'stop', 'time', 'end', 'start', 'opportunity'],
    sourceUrl: 'https://www.gutenberg.org/ebooks/11',
  },
  {
    bookTitle: 'The Picture of Dorian Gray',
    author: 'Oscar Wilde',
    year: '1890',
    passage: 'Experience is merely the name men gave to their mistakes. Youth is the only thing worth having, and wisdom comes only through patience.',
    keywords: ['wisdom', 'experience', 'mistake', 'life', 'youth', 'patience', 'diligent', 'achieve'],
    sourceUrl: 'https://www.gutenberg.org/ebooks/174',
  },
  {
    bookTitle: 'Frankenstein',
    author: 'Mary Shelley',
    year: '1818',
    passage: 'Learn from me, if not by my precepts, at least by my example, how dangerous is the acquirement of knowledge and how much happier that man is who believes his native town to be the world.',
    keywords: ['knowledge', 'learn', 'example', 'world', 'native', 'comprehend', 'perceive'],
    sourceUrl: 'https://www.gutenberg.org/ebooks/84',
  },
  {
    bookTitle: 'Great Expectations',
    author: 'Charles Dickens',
    year: '1861',
    passage: 'We need never be ashamed of our tears, for they are rain upon the blinding dust of earth, overlaying our hard hearts. I was better after I had cried.',
    keywords: ['heart', 'earth', 'tear', 'hope', 'life', 'friend', 'family', 'school'],
    sourceUrl: 'https://www.gutenberg.org/ebooks/1400',
  },
  {
    bookTitle: 'Walden',
    author: 'Henry David Thoreau',
    year: '1854',
    passage: 'If one advances confidently in the direction of his dreams, and endeavors to live the life which he has imagined, he will meet with a success unexpected in common hours.',
    keywords: ['dream', 'success', 'life', 'advance', 'direction', 'achieve', 'persevere', 'goal'],
    sourceUrl: 'https://www.gutenberg.org/ebooks/205',
  },
  {
    bookTitle: 'A Tale of Two Cities',
    author: 'Charles Dickens',
    year: '1859',
    passage: 'It was the best of times, it was the worst of times, it was the age of wisdom, it was the age of foolishness, it was the epoch of belief.',
    keywords: ['time', 'wisdom', 'belief', 'world', 'peace', 'freedom'],
    sourceUrl: 'https://www.gutenberg.org/ebooks/98',
  },
];

class WithdomService {
  /**
   * Search Withdom / Online dictionary and legal literature corpus
   */
  public async search(query: string): Promise<WithdomSearchResult[]> {
    const q = query.trim().toLowerCase();
    if (!q) return [];

    const results: WithdomSearchResult[] = [];

    // 1. Fetch real dictionary entry from FreeDictionary API
    try {
      const dictRes = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(q)}`);
      if (dictRes.ok) {
        const data = await dictRes.json();
        if (Array.isArray(data) && data.length > 0) {
          const entry = data[0];
          const phonetic = entry.phonetic || (entry.phonetics && entry.phonetics.find((p: { text?: string }) => p.text)?.text) || '';
          const audioUrl = entry.phonetics?.find((p: { audio?: string }) => p.audio && p.audio.length > 0)?.audio || '';

          // Find Uzbek translation
          const uzTrans = await translationService.translate(entry.word, 'en_to_uz');

          const definitions: WithdomDefinition[] = [];
          entry.meanings?.forEach((m: {
            partOfSpeech: string;
            definitions: Array<{ definition: string; example?: string; synonyms?: string[] }>;
          }) => {
            m.definitions?.slice(0, 3).forEach((d) => {
              definitions.push({
                definition: d.definition,
                uzbekDefinition: '', // Filled below or left for display
                example: d.example,
                synonyms: d.synonyms?.slice(0, 4),
              });
            });
          });

          // Match relevant book excerpts from our legal public domain corpus
          const matchingExcerpts = this.findCorpusExcerpts(entry.word);

          // Also check OpenLibrary for books related to this word/topic
          const openLibraryBooks = await this.searchOpenLibraryBooks(entry.word);
          const allExcerpts = [...matchingExcerpts, ...openLibraryBooks].slice(0, 4);

          results.push({
            id: 'withdom_dict_' + entry.word,
            word: entry.word,
            phonetic: phonetic || uzTrans.phonetic,
            audioUrl: audioUrl,
            partOfSpeech: entry.meanings?.[0]?.partOfSpeech || uzTrans.partOfSpeech || 'noun',
            primaryTranslationUz: uzTrans.translatedText || 'Tarjimasi kiritilmagan',
            definitions: definitions.slice(0, 5),
            bookExcerpts: allExcerpts,
            sourceName: 'Withdom / Ochiq Lug\'at & Kitoblar Arxivi',
            sourceDescription: 'Xalqaro FreeDictionary leksik bazasi va Project Gutenberg / Open Library ochiq klassik kitoblar korpusi',
            legalNotice: 'Qonuniy ochiq litsenziyali lug\'at va jamoat mulki (Public Domain) kitob parchalari.',
          });
        }
      }
    } catch (e) {
      console.warn('FreeDictionary API chaqiruvida xato:', e);
    }

    // 2. If no dictionary hit, check if the query matches books directly (by title, author or keyword)
    if (results.length === 0) {
      const bookMatches = this.findCorpusExcerpts(q);
      const openLib = await this.searchOpenLibraryBooks(q);
      const combined = [...bookMatches, ...openLib];

      if (combined.length > 0) {
        const uzTrans = await translationService.translate(q, 'en_to_uz');
        results.push({
          id: 'withdom_book_' + Date.now(),
          word: q,
          phonetic: uzTrans.phonetic || '',
          partOfSpeech: uzTrans.partOfSpeech || 'kitob / ibora',
          primaryTranslationUz: uzTrans.translatedText || q,
          definitions: [
            {
              definition: `Ushbu so'z yoki ibora ochiq kutubxona kitoblarida uchradi.`,
              uzbekDefinition: `Topilgan kitob parchalari va kontekst bilan tanishing.`,
            },
          ],
          bookExcerpts: combined.slice(0, 5),
          sourceName: 'Withdom Kitoblar Arxivi',
          sourceDescription: 'Project Gutenberg va Open Library ochiq adabiyotlar bazasi',
          legalNotice: 'Adabiyotlar matnidan qonuniy ta\'limiy parchalar keltirilgan.',
        });
      }
    }

    // 3. If still empty, try translation fallback
    if (results.length === 0) {
      const isEnglish = /^[a-zA-Z\s'-]+$/.test(q);
      const direction = isEnglish ? 'en_to_uz' : 'uz_to_en';
      const tr = await translationService.translate(q, direction);

      if (tr.translatedText) {
        const enWord = isEnglish ? q : tr.translatedText;
        const uzWord = isEnglish ? tr.translatedText : q;
        const bookMatches = this.findCorpusExcerpts(enWord);

        results.push({
          id: 'withdom_trans_' + Date.now(),
          word: enWord,
          phonetic: tr.phonetic || '',
          partOfSpeech: tr.partOfSpeech || 'so\'z',
          primaryTranslationUz: uzWord,
          definitions: [
            {
              definition: tr.exampleEn ? `Misol: ${tr.exampleEn}` : `Bilingual English-Uzbek dictionary definition`,
              uzbekDefinition: tr.exampleUz || uzWord,
              example: tr.exampleEn,
              exampleUz: tr.exampleUz,
            },
          ],
          bookExcerpts: bookMatches.slice(0, 3),
          sourceName: 'Withdom Lug\'at Tizimi',
          sourceDescription: 'O\'zbekcha-Inglizcha lug\'at bazasi',
          legalNotice: 'Mualliflik huquqlariga rioya qilingan holda taqdim etiladi.',
        });
      }
    }

    return results;
  }

  private findCorpusExcerpts(word: string): WithdomBookExcerpt[] {
    const w = word.toLowerCase().trim();
    const matches: WithdomBookExcerpt[] = [];

    for (const item of CLASSIC_LITERATURE_CORPUS) {
      const containsKeyword = item.keywords.some((k) => k.toLowerCase() === w || w.includes(k));
      const containsInText = item.passage.toLowerCase().includes(w);

      if (containsKeyword || containsInText) {
        matches.push({
          bookTitle: item.bookTitle,
          author: item.author,
          year: item.year,
          passage: item.passage,
          highlightWord: w,
          sourceUrl: item.sourceUrl,
        });
      }
    }

    return matches;
  }

  private async searchOpenLibraryBooks(query: string): Promise<WithdomBookExcerpt[]> {
    try {
      const url = `https://openlibrary.org/search.json?q=${encodeURIComponent(query)}&limit=3`;
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        const docs = data.docs || [];
        return docs.map((doc: {
          title: string;
          author_name?: string[];
          first_publish_year?: number;
          first_sentence?: { value: string } | string;
          key: string;
        }) => {
          let sentence = '';
          if (typeof doc.first_sentence === 'string') {
            sentence = doc.first_sentence;
          } else if (doc.first_sentence && typeof doc.first_sentence.value === 'string') {
            sentence = doc.first_sentence.value;
          } else {
            sentence = `Ushbu kitobda "${query}" mavzusi va so'z boyligi batafsil yoritilgan.`;
          }

          return {
            bookTitle: doc.title || 'Noma\'lum kitob',
            author: (doc.author_name && doc.author_name[0]) || 'Klassik muallif',
            year: doc.first_publish_year ? String(doc.first_publish_year) : '',
            passage: sentence,
            highlightWord: query,
            sourceUrl: `https://openlibrary.org${doc.key || ''}`,
          };
        });
      }
    } catch {
      // ignore
    }
    return [];
  }
}

export const withdomService = new WithdomService();
